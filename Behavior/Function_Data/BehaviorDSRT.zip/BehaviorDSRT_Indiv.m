classdef BehaviorDSRT_Indiv
    % Based on BehaviorDSRT
    % Data format containing multiple sessions of one subject
    % METHODS:
    % obj.save(savepath); Save the obj as .mat file & .csv file
        % default path is pwd
    % obj.plot(plotrange, options)
        % plotrange: a vector, only plot the data of obj.DataAll(plotrange)
        % options.plotType
            % value should be one of {'DayByDay','Progress','CompExp'}
            % which represents one type we want
        % options.figSize
            % In 'DayByDay', it is [width height] of the whole figure
            % In 'Progress', it is [width height] of every single session
    
    properties
        DataAll (1,:) cell
        Protocol char {mustBeTextScalar} % e.g., 'WaitPeriod'
        Comment char {mustBeTextScalar}
    end

    properties (Dependent)
        Subject char {mustBeTextScalar} % e.g., Panini
        Strain char {mustBeTextScalar} % e.g., LE
        Group char {mustBeTextScalar} % e.g., hM3Dq (manual or extracted by BehaviorDSRT)
        MixedFP double {mustBeNumeric} % e.g., [0.5 1.0 1.5]1111111
        nSession double {mustBeNumeric}
        Sessions double {mustBeNumeric}
        Dates (1,:) double {mustBeNumeric}
        Weights (1,:) double {mustBeNumeric}
        Tasks (1,:) cell {mustBeText} % e.g., {'Wait1','Wait1','Wait1','Wait2'}
        Experiments (1,:) cell {mustBeText} % e.g., {'Saline','DCZ','Saline','DCZ'}
        nTrial (1,:) double
        TableAll (1,:) cell
        TBT table % trial by trial
        SBS table % session by session, every row: stat for each session * TrialType
        EBE table % experiment by experiment, every row: stat for each Experiment * TrialType
        CBC table % estimates of custom conditions, every row: stat for each custom conditions (e.g., early 200 trials)
        Options struct
    end

    properties (Dependent, GetAccess = private)
        SaveName
    end

    properties (GetAccess = private)
        pTBT table
        pSBS table
        pEBE table
        pCBC table
        Edges_HT = 0:0.05:2.5 % Hold time (All trials)
        Bins_HT = 0.025:0.05:2.475
        Edges_RT = 0:0.025:0.6 % Reaction time (Cor)
        Edges_RelT = 0:0.05:1 % Release time (Cor+Late)
        SmoWin = 8 % smoothdata('gaussian')
        GaussEqn = 'a1*exp(-((x-b1)/c1)^2)+a2*exp(-((x-b2)/c2)^2)'
        StartPoints = [1 1 1 2 2 1]
        LowerBound = [0 0 0 0 0 0]
        UpperBound = [10 10 10 10 10 10]
        ProgressTrials = 600 % all trials
        SlidingMethod = 'fixed'
        SlidingWin = 30
        SlidingStep = 10
        CompExp = {'DCZ25','Saline'} % e.g., {'DCZ','Saline'}
        CompDate = {[],[]} % e.g., {[20230415,20230422],[20230414,20230421]}
        FPLineStyles = {'-',':','-.'}
    end

    properties (Constant, GetAccess = private)
        FigNum = 2
        MergeMethod = {'Merge','Select'}
        DefaultMixedFP = [0.5,1.0,1.5]
    end
    
    methods
        function obj = BehaviorDSRT_Indiv(behavDSRTAll,protocol,comment,options)
            arguments
                behavDSRTAll (1,:) cell
                protocol char {mustBeTextScalar} = ''
                comment char {mustBeTextScalar} = ''
                options.Subject char {mustBeTextScalar} = ''
                options.Strain char {mustBeTextScalar} = ''
                options.Group char {mustBeTextScalar} = ''
                options.Experimenter string {mustBeText} = ""
                options.Comments string {mustBeText} = ""
                options.Experiments string {mustBeText} = ""
                options.Weights double {mustBeNumeric} = []
                options.Sessions double {mustBeNumeric} = []
                options.MergeMethod char {mustBeMember(options.MergeMethod,{'Merge','Select'})} = 'Merge'
            end
            
            obj.Protocol = protocol;
            obj.Comment = comment;
            dataAll = Merge1DayDSRT(behavDSRTAll,options.MergeMethod); % Merge 1 day's data
            nData = length(dataAll);
            % add some information
            isSession = cellfun(@(x)~isnan(x.Session),dataAll,'UniformOutput',true);
            for k=1:nData
                % add session information
                if ~any(isSession)
                    if k == 1
                        kk = 1;
                    else
                        if string(dataAll{1, k}.Task) ~= string(dataAll{1, k-1}.Task)
                            kk = 1;
                        else
                            kk = kk + 1;
                        end
                    end
                    if isempty(options.Sessions) || length(options.Sessions)~=nData
                        dataAll{k}.Session = kk;
                    else
                        dataAll{k}.Session = options.Sessions(k);
                    end
                end
                % add optional information
                if ~isempty(options.Subject)
                    dataAll{k}.Subject = options.Subject;
                end
                if ~isempty(options.Strain)
                    dataAll{k}.Strain = options.Strain;
                end
                if ~isempty(options.Group)
                    dataAll{k}.Group = options.Group;
                end
                if any(strlength(options.Experimenter))>0 % isempty("")==false
                    if length(options.Experimenter)==nData
                        dataAll{k}.Experimenter = options.Experimenter{k};
                    elseif length(options.Experimenter)==1
                        dataAll{k}.Experimenter = char(options.Experimenter);
                    else
                        warning('The length of Experimenter is not equal to nSession. Skip the setting.');
                    end
                end
                if any(strlength(options.Comments))>0
                    if length(options.Comments)==nData
                        dataAll{k}.Comment = options.Comments{k};
                    elseif length(options.Comments)==1
                        dataAll{k}.Comment = char(options.Comments);
                    else
                        warning('The length of Comment is not equal to nSession. Skip the setting.');
                    end
                end
                if any(strlength(options.Experiments))>0
                    if length(options.Experiments)==nData
                        dataAll{k}.Experiment = options.Experiments{k}; % string{1} = 'str', string(1) = "str".
                    elseif length(options.Experiments)==1
                        dataAll{k}.Experiment = char(options.Experiments);
                    else
                        warning('The length of Experiments is not equal to nSession. Skip the setting.');
                    end
                end
                if ~isempty(options.Weights)
                    if length(options.Weights)==nData
                        dataAll{k}.Weight = options.Weights{k}; % string{1} = 'str', string(1) = "str".
                    elseif length(options.Weights)==1
                        dataAll{k}.Weight = options.Weights;
                    else
                        warning('The length of Weights is not equal to nSession. Skip the setting.');
                    end
                end
                if ~isempty(options.Sessions)
                    if length(options.Sessions)==nData
                        dataAll{k}.Session = options.Sessions{k}; % string{1} = 'str', string(1) = "str".
                    elseif length(options.Sessions)==1
                        dataAll{k}.Session = options.Sessions;
                    else
                        warning('The length of Weights is not equal to nSession. Skip the setting.');
                    end
                end
            end
            obj.DataAll = dataAll;

            obj = obj.stat;

            function out = Merge1DayDSRT(behavDSRTAll,varargin)
                p = inputParser;
                addRequired(p,'behavDSRTAll',@iscell);
                addOptional(p,'method','Merge',@mustBeTextScalar);
                parse(p,behavDSRTAll,varargin{:});
                method = p.Results.method;
                
                dates = cellfun(@(x)x.Date,behavDSRTAll,'UniformOutput',true);
                [~,ia,~] = unique(dates,'stable');

                out = cell(1,length(ia));
                for i=1:length(out)
                    out{i} = behavDSRTAll{ia(i)};
                    for j=1:length(behavDSRTAll)
                        if ia(i)~=j
                            out{i} = out{i}.merge(behavDSRTAll{j},method,true);
                        end
                    end
                end
            end
        end

        function value = get.Subject(obj)
            value = unique(string(cellfun(@(x)x.Subject,obj.DataAll,'UniformOutput',false)));
            mustBeTextScalar(value);
            value = char(value);
        end

        function obj = set.Subject(obj,value)
            for i=1:obj.nSession
                obj.DataAll{i}.Subject = char(value);
            end
        end

        function value = get.Strain(obj)
            value = unique(string(cellfun(@(x)x.Strain,obj.DataAll,'UniformOutput',false)));
            mustBeTextScalar(value);
            value = char(value);
        end

        function obj = set.Strain(obj,value)
            for i=1:obj.nSession
                obj.DataAll{i}.Strain = char(value);
            end
        end

        function value = get.Group(obj)
            value = unique(string(cellfun(@(x)x.Group,obj.DataAll,'UniformOutput',false)));
            mustBeTextScalar(value);
            value = char(value);
        end

        function obj = set.Group(obj,value)
            for i=1:obj.nSession
                obj.DataAll{i}.Group = char(value);
            end
        end
        
        function value = get.MixedFP(obj)
            valueAll = cellfun(@(x)num2str(x.MixedFP),obj.DataAll,'UniformOutput',false);
            valueUni = unique(valueAll,'stable');
            if length(valueUni)>1 % different MixedFPs exist
                mfp = cell(size(valueUni));
                for iVal=1:length(valueUni)
                    mfp{iVal} = str2num(valueUni{iVal});
                end
                value = mfp{end};
                warning('The value of MixedFP is not unique among exsiting sessions. Using the most recent session''s value: %s',num2str(value));
            elseif length(valueUni)==1
                value = str2num(valueUni{1});
            else
                warning('Invalid value of MixedFPs. Using DefaultMixedFP: %s',num2str(obj.DefaultMixedFP));
                value = obj.DefaultMixedFP;
            end
        end

        function obj = set.MixedFP(obj,value)
            for i=1:obj.nSession
                obj.MixedFP = value;
            end
        end

        function value = get.nSession(obj)
            value = length(obj.DataAll);
        end

        function value = get.Sessions(obj)
            value = cellfun(@(x)x.Session,obj.DataAll,'UniformOutput',true);
        end

        function obj = set.Sessions(obj,value)
            for i=1:obj.nSession
                obj.DataAll{i}.Session = value(i);
            end
        end

        function value = get.Dates(obj)
            value = cellfun(@(x)x.Date,obj.DataAll,'UniformOutput',true);
        end

        function value = get.Weights(obj)
            value = cellfun(@(x)x.Weight,obj.DataAll,'UniformOutput',true);
        end

        function obj = set.Weights(obj,value)
            for i=1:obj.nSession
                obj.DataAll{i}.Weight = value(i);
            end
        end
            
        function value = get.Tasks(obj)
            value = cellfun(@(x)x.Task,obj.DataAll,'UniformOutput',false);
        end

        function value = get.Experiments(obj)
            value = cellfun(@(x)x.Experiment,obj.DataAll,'UniformOutput',false);
        end
        
        function obj = set.Experiments(obj,value)
            for i=1:obj.nSession
                obj.DataAll{i}.Experiment = value{i}; % string{i}
            end
        end

        function value = get.nTrial(obj)
            value = cellfun(@(x)x.nTrial,obj.DataAll,'UniformOutput',true);
        end

        function value = get.TableAll(obj)
            value = cell(1,obj.nSession);
            for i=1:obj.nSession
                value{i} = obj.DataAll{i}.Table;
            end
        end

        function value = get.TBT(obj)
            value = obj.pTBT;
        end

        function value = get.SBS(obj)
            value = obj.pSBS;
        end
        
        function value = get.EBE(obj)
            value = obj.pEBE;
        end

        function value = get.CBC(obj)
            value = obj.pCBC;
        end
        
        function value = get.Options(obj)
            value = struct;
            value.Edges_HT = obj.Edges_HT;
            value.Bins_HT = obj.Bins_HT;
            value.Edges_RT = obj.Edges_RT;
            value.Edges_RelT = obj.Edges_RelT;
            value.SmoothWindow = obj.SmoWin;
            value.GaussEqn = obj.GaussEqn;
            value.StartPoints = obj.StartPoints;
            value.LowerBound = obj.LowerBound;
            value.UpperBound = obj.UpperBound;
            value.ProgressTrials = obj.ProgressTrials;
            value.SlidingMethod = obj.SlidingMethod;
            value.SlidingWindow = obj.SlidingWin;
            value.SlidingStep = obj.SlidingStep;
            value.CompExp = obj.CompExp;
            value.CompDate = obj.CompDate;
            value.FPLineStyles = obj.FPLineStyles;
        end

        function obj = set.Options(obj,value)
            isSameFields = isequal(fieldnames(obj.Options),fieldnames(value));
            if isSameFields
                obj.Edges_HT = value.Edges_HT;
                obj.Bins_HT = value.Bins_HT;
                obj.Edges_RT = value.Edges_RT;
                obj.Edges_RelT = value.Edges_RelT;
                obj.SmoWin = value.SmoothWindow;
                obj.GaussEqn = value.GaussEqn;
                obj.StartPoints = value.StartPoints;
                obj.LowerBound = value.LowerBound;
                obj.UpperBound = value.UpperBound;
                obj.ProgressTrials = value.ProgressTrials;
                obj.SlidingMethod = value.SlidingMethod;
                obj.SlidingWin = value.SlidingWindow;
                obj.SlidingStep = value.SlidingStep;
                obj.CompExp = value.CompExp;
                obj.CompDate = value.CompDate;
                obj.FPLineStyles = value.FPLineStyles;
            else
                error('Unmatched fieldnames of Options');
            end
        end

        function obj = stat(obj)
            obj.pTBT = tbt(obj);
            obj.pSBS = sbs(obj);
            obj.pEBE = ebe(obj);
            obj.pCBC = cbc(obj);
        end

        function value = tbt(obj)
            value = table;
            for i=1:obj.nSession
                T = obj.TableAll{i};
                value = [value;T];
            end
        end

        function value = sbs(obj)
            value = table;
            for i=1:obj.nSession
                data = obj.TableAll{i};
                stat = calIndivStat(data,'ifDistr',true,'fplist',obj.MixedFP,...
                    'edges_HT',obj.Edges_HT,'bins_HT',obj.Bins_HT,...
                    'edges_RT',obj.Edges_RT,'edges_RelT',obj.Edges_RelT,...
                    'smoWin',obj.SmoWin,'GaussEqn',obj.GaussEqn,...
                    'StartPoints',obj.StartPoints,'LowerBound',obj.LowerBound,'UpperBound',obj.UpperBound);
                % Add progress performance for each session
                % By "fixed" slidingMethod, each session has different
                % length, we just append them as struct.
                iobj = obj.DataAll{i};
                switch lower(obj.SlidingMethod)
                    case 'fixed'
                        iprgPerf = iobj.calProgress("Outcome",'tarStr',{'Cor','Pre','Late'},...
                            'slidingMethod',obj.SlidingMethod,'winSize',obj.SlidingWin,'stepSize',obj.SlidingStep);
                        iprgRT = iobj.calProgress("RT",'tarStr',{'Cor','CorLate'},...
                            'slidingMethod',obj.SlidingMethod,'winSize',obj.SlidingWin,'stepSize',obj.SlidingStep);
                        iprgFP = iobj.calProgress("FP",'tarStr',{'All'},...
                            'slidingMethod',obj.SlidingMethod,'winSize',obj.SlidingWin,'stepSize',obj.SlidingStep);
                    case 'ratio'
                        iprgPerf = iobj.calProgress("Outcome",'tarStr',{'Cor','Pre','Late'},...
                            'slidingMethod',obj.SlidingMethod,'winRatio',obj.SlidingWin,'stepRatio',obj.SlidingStep);
                        iprgRT = iobj.calProgress("RT",'tarStr',{'Cor','CorLate'},...
                            'slidingMethod',obj.SlidingMethod,'winRatio',obj.SlidingWin,'stepRatio',obj.SlidingStep);
                        iprgFP = iobj.calProgress("FP",'tarStr',{'All'},...
                            'slidingMethod',obj.SlidingMethod,'winRatio',obj.SlidingWin,'stepRatio',obj.SlidingStep);
                    otherwise
                        error('Invalid parameters of SlidingMethod');
                end
                
                stat = addvars(stat, obj.SlidingWin, obj.SlidingStep, {iprgFP.x.All}, {iprgPerf.y}, {iprgRT.y}, {iprgFP.y},...
                    'NewvariableNames', {'progressWin', 'progressStep', 'progressTime', 'progressPerf', 'progressRT', 'progressFP'});
                
                % Add FP-divided progress data, and trim to same length(yFP)
                for iFP = 1:length(obj.MixedFP)
                    if iobj.Task == "3FPs"
                        yFP = min([height(iprgPerf.x1(:,1)),height(iprgPerf.x2(:,1)),height(iprgPerf.x3(:,1))]);
                        iprg.("Time_FP"+string(iFP)) = iprgPerf.("x"+string(iFP)).Cor(1:yFP);
                        iprg.("Perf_FP"+string(iFP)) = iprgPerf.("y"+string(iFP))(1:yFP,:);
                        iprg.("RT_FP"+string(iFP))   = iprgRT.("y"+string(iFP))(1:yFP,:);
                    else
                        iprg.("Time_FP"+string(iFP)) = [];
                        iprg.("Perf_FP"+string(iFP)) = [];
                        iprg.("RT_FP"+string(iFP))   = [];
                    end
                    stat = addvars(stat, {iprg.("Time_FP"+string(iFP))},...
                        'NewVariableNames',cellstr("progressTime_FP"+string(iFP)));
                    stat = addvars(stat, {iprg.("Perf_FP"+string(iFP))}, ...
                        'NewVariableNames',cellstr("progressPerf_FP"+string(iFP)));
                    stat = addvars(stat, {iprg.("RT_FP"+string(iFP))}, ...
                        'NewVariableNames',cellstr("progressRT_FP"+string(iFP)));
                end
                value = [value;stat];
            end
        end
        
        function value = ebe(obj)
            value = table;
            uniExp = unique(obj.Experiments);
            for i=1:length(uniExp)
                data = obj.TBT(obj.TBT.Experiment==uniExp{i},:);
                stat = calIndivStat(data,true,'ifDistr',true,'fplist',obj.MixedFP,...
                    'edges_HT',obj.Edges_HT,'bins_HT',obj.Bins_HT,...
                    'edges_RT',obj.Edges_RT,'edges_RelT',obj.Edges_RelT,...
                    'smoWin',obj.SmoWin,'GaussEqn',obj.GaussEqn,...
                    'StartPoints',obj.StartPoints,'LowerBound',obj.LowerBound,'UpperBound',obj.UpperBound);
                value = [value;stat];
            end
%             value = table2struct(value);
        end

        function value = cbc(obj)
            % Existing conditions:
                % Early ProgressTrials (e.g., first 200) of TBT
                % Late ProgressTrials (e.g., last 200) of TBT
            value = table;
            progTrials = min(obj.ProgressTrials,size(obj.TBT,1));
            % Early ProgressTrials
            data = obj.TBT(1:progTrials,:);
            stat = calIndivStat(data,true,'ifDistr',true,'fplist',obj.MixedFP,...
                'edges_HT',obj.Edges_HT,'bins_HT',obj.Bins_HT,...
                'edges_RT',obj.Edges_RT,'edges_RelT',obj.Edges_RelT,...
                'smoWin',obj.SmoWin,'GaussEqn',obj.GaussEqn,...
                'StartPoints',obj.StartPoints,'LowerBound',obj.LowerBound,'UpperBound',obj.UpperBound);
            value = [value;stat];
            % Late ProgressTrials
            data = obj.TBT(end-progTrials+1:end,:);
            stat = calIndivStat(data,true,'ifDistr',true,'fplist',obj.MixedFP,...
                'edges_HT',obj.Edges_HT,'bins_HT',obj.Bins_HT,...
                'edges_RT',obj.Edges_RT,'edges_RelT',obj.Edges_RelT,...
                'smoWin',obj.SmoWin,'GaussEqn',obj.GaussEqn,...
                'StartPoints',obj.StartPoints,'LowerBound',obj.LowerBound,'UpperBound',obj.UpperBound);
            value = [value;stat];

            value = addvars(value,["EarlyProgress";"LateProgress"],...
                'NewVariableNames','Customization','Before','Subject');
        end

        function value = get.SaveName(obj)
            if isempty(obj.Protocol)
                value = append('BClassIndiv_',upper(obj.Subject),'_',...
                    num2str(min(obj.Dates)),'-',num2str(max(obj.Dates)));
            else
                value = append('BClassIndiv_',upper(obj.Subject),'_',...
                    obj.Protocol);
            end
        end

        function obj = reNumber(obj, expStr)
            expAll = obj.Experiments;
            newSess = zeros(size(expAll));
            kk = 1;
            if nargin == 1
                % simply renumber sessions as 1~n for each experiment
                for i = 1:length(expAll)
                    if ~isempty(expAll{i})
                        if i > 1
                            if string(expAll{i}) ~= string(expAll{i-1})
                                kk = 1;
                            else
                                kk = kk + 1;
                            end
                        end
                        newSess(i) = kk;
                    end
                end
            else
                idx1 = find(strcmp(expAll, expStr{1}));
                idx2 = find(strcmp(expAll, expStr{2}));
                if ~isempty(idx1)
                    newSess(idx1) = idx1-idx1(end)-1;
                end
                if ~isempty(idx2)
                    newSess(idx2) = idx2-idx2(1)+1;
                end
            end
            obj.Sessions = newSess;
        end

        function obj = reExp(obj, slctSes, newExp)
            if height(slctSes) ~= height(newExp)
                error('Check inputs length: Sessions ~ Experiments');
            end
            sesAll = obj.Sessions;
            expCell = cell(size(sesAll));
            for i = 1:length(sesAll)
                for k = 1:height(slctSes)
                    if ismember(sesAll(i), slctSes(k,:))
                        expCell{i} = newExp{k};
                    end
                end
                if isempty(expCell{i})
                    expCell{i} = 'reject';
                end
            end
            obj.Experiments = expCell;
        end

        function save(obj, savepath)
            arguments
                obj
                savepath = pwd
            end
            [~,~] = mkdir(savepath);
            save(fullfile(savepath,obj.SaveName),'obj');
            writetable(obj.TBT,fullfile(savepath,append(obj.SaveName,'.csv')));
        end

        function r = print(obj, options)
            arguments
                obj
                options.saveName char {mustBeText} = '';
                options.tarFig {mustBeA(options.tarFig, 'matlab.ui.Figure')} = []
                options.tarDir char {mustBeText} = pwd;
            end
            targetDir = options.tarDir;

            if isempty(options.tarFig)
                targetFig = obj.plot;
            else
                targetFig = options.tarFig;
            end

            if isempty(options.saveName)
                saveName = obj.SaveName;
            else
                saveName = obj.SaveName + "_" + options.saveName;
            end
            [~,~] = mkdir(targetDir);
            saveName = fullfile(targetDir,saveName);
            saveas(targetFig, saveName, 'fig');
%             export_fig(hf,savename,'-png','-eps');
            print(targetFig,'-dpng', saveName);
            exportgraphics(targetFig,append(saveName,'.eps'),'ContentType','vector');
            r = 1;
        end

        function fig = plot(obj,options)
            arguments
                obj
                options.plotType char {mustBeMember(options.plotType,{'Learning','Progress','CompExp','MixedFP','CompDay'})} = 'Learning'
                options.figSize double = []
                options.slctSession double = []
                options.expName (:,1) cell {mustBeText} = {}
                options.grpStr (:,1) string {mustBeText} = []
                options.shadedExp char = 'DCZ'
            end
            Obj = obj;
            figSize = options.figSize;
            
            % Set experiment names
            if ~isempty(options.expName)
                expName = options.expName;
            else
                disp('No "expName" inputs, use default settings.');
                expName = unique(Obj.Experiments(1,:));
            end
            if length(expName) > 2
                error('Check "expName" inputs or "Experiment" in TrainingLog*.xls');
            end

            % Parameters
            fontAxesSz = 7;
            fontLablSz = 9;
            fontTitlSz = 10;
            cTab10 = tab10(10);
            cBlue = cTab10(1,:);
            cOrange = cTab10(2,:);
            cGreen = cTab10(3,:);
            cRed = cTab10(4,:);
            cGray = cTab10(8,:);
            cBrown = cTab10(6,:);
            cCyan = cTab10(10,:);
            cCPL = [cGreen;cRed;cGray];
            cExp = [cOrange;cGray];
            c3FPs = [cGray;mean([cOrange;cGray]);cOrange];
            set(groot,'defaultAxesFontName','Helvetica');
            
            switch lower(options.plotType)
                case 'learning'
                    fig = learningPlot(Obj);
                case 'progress'
                    fig = progressPlot(Obj);
                case 'compexp'
                    fig = compExpPlot(Obj);
                case 'mixedfp'
                    fig = mixedFPsPlot(Obj,'shadedExp',options.shadedExp);
                case 'compday'
                    fig = compDayPlot(Obj);
            end
            
            function h = compDayPlot(Obj)
                % adapted from BehaviorGroupClass.PlotChemoEffect writed by Jianing Yu
                try
                    idxSession1 = find(ismember(Obj.Experiments,Obj.CompExp{1}) & ismember(Obj.Dates,Obj.CompDate{1}));
                    idxSession2 = find(ismember(Obj.Experiments,Obj.CompExp{2}) & ismember(Obj.Dates,Obj.CompDate{2}));
                    if length(idxSession1)~=length(idxSession2)
                        minLen = min(length(idxSession1),length(idxSession2));
                        idxSession1 = idxSession1(1:minLen);
                        idxSession2 = idxSession2(1:minLen);
                    end
                catch ME
                    msg = ('Invalid arguments (CompExp/CompDate) in Options');
                    causeException = MException('MYFUN:invalidFormat',msg);
                    ME = addCause(ME,causeException);
                    rethrow(ME);
                end
                
                opts = Obj.Options; protocol = Obj.Protocol;
                Obj = BehaviorDSRT_Indiv(Obj.DataAll(union(idxSession1,idxSession2))); % Only use the selected sessions
                Obj.Options = opts; Obj.Protocol = protocol;

                idxDates1 = find(ismember(Obj.Experiments,Obj.CompExp{1}) & ismember(Obj.Dates,Obj.CompDate{1}));
                idxDates2 = find(ismember(Obj.Experiments,Obj.CompExp{2}) & ismember(Obj.Dates,Obj.CompDate{2}));

                e1 = Obj.EBE(strcmp(Obj.EBE.Experiment, Obj.CompExp{1}),:); % e.g., DCZ
                e2 = Obj.EBE(strcmp(Obj.EBE.Experiment, Obj.CompExp{2}),:); % e.g., Saline
                s1 = Obj.SBS(strcmp(Obj.SBS.Experiment, Obj.CompExp{1}),:);
                s2 = Obj.SBS(strcmp(Obj.SBS.Experiment, Obj.CompExp{2}),:);
                t1 = Obj.TBT(strcmp(Obj.TBT.Experiment, Obj.CompExp{1}),:);
                t2 = Obj.TBT(strcmp(Obj.TBT.Experiment, Obj.CompExp{2}),:);

                set_matlab_default;
                % This is to plot pre and post lesion hold time PDF, which gives
                % a quick show on the effect
                col_perf = [85 225 0
                    255 0 0
                    140 140 140]/255;
                FPs = Obj.MixedFP;
                tBins = Obj.Edges_HT;
                colors = {[0 0 0.6], [255, 201, 60]/255};
                FPColors = [45, 205, 223]/255;
                WhiskerColor = [255, 0, 50]/255;
    
                SessionsCol = [3, 0, 28]/255;
                TrialsCol = [91, 143, 185]/255;
    
                h = figure(Obj.FigNum); clf(h)
                set(h, 'unit', 'centimeters', 'position',[2 2 32 15], 'paperpositionmode', 'auto', 'color', 'w')
    
                StrictSymbol = 'o';
                LooseSymbol = 's';
                CIColor = [0 0 0];
    
                ylevel = 1.25;
                xlevel = 1.5;
    
                ha_RT1 = axes('nextplot', 'add', 'unit', 'centimeters', 'position',[xlevel ylevel 5 5], 'xlim', [0.1 0.8], ...
                    'xtick',[0.2:0.2:0.8], 'ylim', [0.1 0.8],'ytick', [0:0.2:1], 'ticklength', [0.02 0.1]);
                line([0 1], [0 1], 'linestyle','-.', 'linewidth', 1, 'color', [0.6 0.6 0.6])
                title('Reaction time')
                xlabel(append(Obj.CompExp{2},' (sec)'));
                ylabel(append(Obj.CompExp{1},' (sec)'));
                
                for i =1:length(Obj.MixedFP)
                    line(e2.RT_CI95_FP(i.*[1,2]), repmat(e1.RT_FP(i),[1 2]), 'linewidth', 1.0, 'color',CIColor);
                    line(repmat(e2.RT_FP(i),[1 2]), e1.RT_CI95_FP(i.*[1,2]), 'linewidth', 1.0, 'color',CIColor);
                    line(e2.RelT_CI95_FP(i.*[1,2]), repmat(e1.RelT_FP(i),[1 2]), 'linewidth', 1.0, 'color',CIColor);
                    line(repmat(e2.RelT_FP(i),[1 2]), e1.RelT_CI95_FP(i.*[1,2]), 'linewidth', 1.0, 'color',CIColor);
                end
    
                MarkerAlpha = 0.5;
    
                for i =1:length(Obj.MixedFP)
                    MarkerSize = 35+35*(i-1);
                    scatter(e2.RT_FP(i),e1.RT_FP(i),...
                        'Marker', StrictSymbol, 'SizeData', MarkerSize, 'LineWidth', 1, ...
                        'MarkerFaceColor', SessionsCol, 'MarkerEdgeColor', 'none', 'MarkerFaceAlpha',MarkerAlpha);
                    scatter(e2.RelT_FP(i),e1.RelT_FP(i),...
                        'Marker', LooseSymbol, 'SizeData', MarkerSize, 'LineWidth', 1, ...
                        'MarkerFaceColor', SessionsCol, 'MarkerEdgeColor', 'none', 'MarkerFaceAlpha',MarkerAlpha);
                end
    
                scatter(0.7, 0.3, 'Marker', StrictSymbol, 'SizeData', MarkerSize, 'LineWidth', 1, ...
                    'MarkerFaceColor', SessionsCol, 'MarkerEdgeColor', 'none', 'MarkerFaceAlpha',MarkerAlpha);
                text(0.75, 0.3, 'Strict', 'fontName', 'dejavu sans', 'fontsize', 8)
                scatter(0.7, 0.25, 'Marker', LooseSymbol, 'SizeData', MarkerSize, 'LineWidth', 1, ...
                    'MarkerFaceColor', SessionsCol, 'MarkerEdgeColor', 'none', 'MarkerFaceAlpha',MarkerAlpha);
                text(0.75, 0.25, 'Loose', 'fontName', 'dejavu sans', 'fontsize' , 8)
                title(['RT: ' Obj.CompExp{2} ' vs ' Obj.CompExp{1}],'fontsize', 8, 'FontWeight','bold','FontName','dejavu sans')
    
                xlevel = xlevel +6.5;
                maxIQR = max([e2.HT_IQR_FP e1.HT_IQR_FP])*1.25;
    
                ha_IQR = axes('nextplot', 'add', 'unit', 'centimeters', 'position',[xlevel ylevel 5 5], 'xlim', [0 maxIQR], ...
                    'xtick',[0:0.1:5], 'ylim', [0 maxIQR],'ytick', [0:0.1:5], 'ticklength', [0.02 0.1]);
                line([0 maxIQR], [0 maxIQR], 'linestyle','-.', 'linewidth', 1, 'color', [0.6 0.6 0.6])
                xlabel(append(Obj.CompExp{2},' (sec)'));
                ylabel(append(Obj.CompExp{1},' (sec)'));
                title('Hold duration IQR')
    
                SessionsSymbol = 'd';
                TrialsSymbol = 'o';
                MarkerAlpha = 0.6;
    
                for i =1:length(Obj.MixedFP)
                    MarkerSize = 35+35*(i-1);
                    scatter(e2.HT_IQR_FP(i), e1.HT_IQR_FP(i), ...
                        'Marker', SessionsSymbol, 'SizeData', MarkerSize, 'LineWidth', 1, ...
                        'MarkerFaceColor', SessionsCol, 'MarkerEdgeColor', 'none', 'MarkerFaceAlpha',MarkerAlpha);
                end
    
                ylevel2 = ylevel+7.5;
                xlevel = 8.5 + 6.5;
                
                % CDF 
                ha1c = axes('nextplot', 'add', 'unit', 'centimeters', 'position',[xlevel ylevel2 5 5], 'xlim', [0 3], 'xtick', [0:0.5:3], 'ylim', [0 1], 'ticklength', [0.02 0.1]);
                xlabel('Hold duration (s)')
                ylabel('CDF')
    
                for i =1:length(Obj.MixedFP)           
                    plot(ha1c, Obj.Bins_HT,e2.(['HTcdf_FP' num2str(i)]), 'color', colors{1}, 'linewidth', 2, 'linestyle', Obj.FPLineStyles{i});
                    plot(ha1c, Obj.Bins_HT,e1.(['HTcdf_FP' num2str(i)]), 'color', colors{2}, 'linewidth', 2, 'linestyle', Obj.FPLineStyles{i});
                end
    
                for k =1:length(FPs)    % first, draw FPs
                    line(ha1c, [FPs(k) FPs(k)],  [0 1],'linestyle', Obj.FPLineStyles{k}, 'color', FPColors, 'linewidth', 1)
                end
    
                %             % add legend
                %             line(ha1s, [2.5 2.8]-0.5, [maxPDF maxPDF], 'color', colors{1}, 'linewidth', 2)
                %             text(ha1s, 2.85-0.5, maxPDF, 'Control', 'fontname', 'dejavu sans','fontsize',  7);
                %             line(ha1s, [2.5 2.8]-0.5, [maxPDF*0.9 maxPDF*0.9], 'color', colors{2}, 'linewidth', 2)
                %             text(ha1s, 2.85-0.5, maxPDF*0.9, 'Chemo', 'fontname', 'dejavu sans','fontsize',  7);
    
                xlevel = 8.5;
    
                % PDF
                ha1s = axes('nextplot', 'add', 'unit', 'centimeters', 'position',[xlevel ylevel2 5 5], 'xlim', [0 3], 'xtick', [0:0.5:3], 'ylim', [0 5], 'ticklength', [0.02 0.1]);
                xlabel('Hold duration (s)')
                ylabel('PDF (1/s)')
                
                maxHT = [];
                for i=1:length(Obj.MixedFP)
                    maxHT = [maxHT, max(Obj.EBE.(['HTpdf_FP' num2str(i)]),[],2)'];
                end
                maxPDF = max(maxHT)*1.25;
    
                for i =1:length(Obj.MixedFP)           
                    plot(ha1s, Obj.Bins_HT,e2.(['HTpdf_FP' num2str(i)]), 'color', colors{1}, 'linewidth', 2, 'linestyle', Obj.FPLineStyles{i});
                    plot(ha1s, Obj.Bins_HT,e1.(['HTpdf_FP' num2str(i)]), 'color', colors{2}, 'linewidth', 2, 'linestyle', Obj.FPLineStyles{i});
                end
                set(ha1s, 'ylim', [0, maxPDF])
     
                for k =1:length(FPs)    % first, draw FPs
                    line(ha1s, [FPs(k) FPs(k)],  [0 maxPDF],'linestyle', Obj.FPLineStyles{k}, 'color', FPColors, 'linewidth', 1)
                end
        
                % add legend
                line(ha1s, [2.5 2.8]-0.5, [maxPDF maxPDF], 'color', colors{1}, 'linewidth', 2)
                text(ha1s, 2.85-0.5, maxPDF, Obj.CompExp{2}, 'fontname', 'dejavu sans','fontsize',  7);
                line(ha1s, [2.5 2.8]-0.5, [maxPDF*0.9 maxPDF*0.9], 'color', colors{2}, 'linewidth', 2)
                text(ha1s, 2.85-0.5, maxPDF*0.9, Obj.CompExp{1}, 'fontname', 'dejavu sans','fontsize',  7);
                % Plot data in a violin plot to show all data points



                % Plot data in a violin plot to show all data points
                HoldTimeMax = 3;
                xlevel = 1.5;
    
                % Violin plot of hold duration distribution 
    
                ha2s = axes('nextplot', 'add', 'unit', 'centimeters', 'position',[xlevel ylevel2 5 5], 'xlim', [0 length(FPs)*2+1], 'xtick', [0:1:6], 'ylim', [0 HoldTimeMax], 'ticklength', [0.02 0.1], ...
                    'yscale', 'linear', 'xticklabelrotation', 0, 'FontSize', 7);
     
                % Violinplot based on sessions
                HoldTimeAll = [];
                HoldTimeFPType = [];
                acc = 0;
    
                for k =1:length(FPs)
                    acc = acc + 1;
                    % Control
                    HoldTk = t2.HT(abs(t2.FP-FPs(k))<1e-3);
                    HoldTk(HoldTk > 10) = [];
                    HoldTimeAll = [HoldTimeAll; HoldTk];
                    HoldTimeFPType = [HoldTimeFPType acc*ones(1, length(HoldTk))];
    
                    acc = acc + 1;
%                     % DCZ
%                     if isempty(obj.PDF_HoldT_Chemo)
%                         return
%                     end
%     
                    HoldTk = t1.HT(abs(t1.FP-FPs(k))<1e-3);
                    HoldTk(HoldTk > 10) = [];
                    if ~isempty(HoldTk)
                        HoldTimeAll = [HoldTimeAll; HoldTk];
                        HoldTimeFPType = [HoldTimeFPType acc*ones(1, length(HoldTk))];
                    else
                        HoldTimeAll = [HoldTimeAll; rand(1, 100)/10];
                        HoldTimeFPType = [HoldTimeFPType acc*ones(1,100)];
                    end
                end
    
                axes(ha2s)
                hVio1 = violinplot(HoldTimeAll',  HoldTimeFPType, 'Width', 0.4, 'ViolinAlpha', 0.2, 'ShowWhiskers', false,'Bandwidth', 0.2);
    
                for iv =1:length(hVio1)
                    if rem(iv, 2)~=0
                        hVio1(iv).EdgeColor = 'k';
                        hVio1(iv).ScatterPlot.MarkerFaceColor =colors{1};
                    else
                        hVio1(iv).EdgeColor ='k';
                        hVio1(iv).ScatterPlot.MarkerFaceColor =colors{2};
                    end
    
                    hVio1(iv).ScatterPlot.MarkerFaceAlpha = 0.35;
                    hVio1(iv).ViolinPlot.LineWidth  = 0.5;
                    hVio1(iv).ScatterPlot.SizeData = 6;
                    hVio1(iv).BoxPlot.LineWidth = 1;
                    hVio1(iv).BoxColor = [0.8 0 0.2];
                    hVio1(iv).ViolinPlot.FaceColor = [0.8 0.8 0.8];
                end
    
                for k =1:length(Obj.MixedFP)
                    line([-0.4 1.4]+1+2*(k-1), [FPs(k) FPs(k)],  'linestyle', Obj.FPLineStyles{k}, 'color', FPColors, 'linewidth', 1)
                end
                set(gca, 'xticklabel', num2cell(Obj.MixedFP), 'box', 'off', 'xlim', [0.5 2*length(Obj.MixedFP)+.5])
                xlabel('FP (ms)')
                ylabel('Hold time (s)')
    
                % Plot performance
                xlevel = xlevel +13;
                plotsize_perf = [5 5];
                ha_Performance= axes;
    
                set(ha_Performance,  'units', 'centimeters', 'position', [xlevel, ylevel, plotsize_perf], 'nextplot', 'add', ...
                    'ylim', [-5 100], 'xlim', [-5 100], 'yscale', 'linear', ...
                    'xtick',[0:20:100], 'TickLength', [0.01 0.1]);
                xlabel(Obj.CompExp{2})
                ylabel(Obj.CompExp{1})
                title('Performance')
                line([-5 100], [-5 100], 'color', [0.5 0.5 0.5], 'linestyle', '-.');
    
                for k =1:length(Obj.MixedFP)
                    symbolSize = 20+20*(k-1);
                    ha_scatter_correct= scatter(100*e2.Cor_FP(k), 100*e1.Cor_FP(k), ...
                        'Marker', 'o', 'MarkerEdgeColor',  col_perf(1, :), 'MarkerFaceColor',  col_perf(1, :), 'SizeData', symbolSize, 'MarkerFaceAlpha', 0.6);
                    ha_scatter_premature = scatter(100*e2.Pre_FP(k), 100*e1.Pre_FP(k), ...
                        'Marker', 'o', 'MarkerEdgeColor',  col_perf(2, :), 'MarkerFaceColor',  col_perf(2, :), 'SizeData', symbolSize, 'MarkerFaceAlpha', 0.6);
                    ha_scatter_late = scatter(100*e2.Late_FP(k), 100*e1.Late_FP(k), ...
                        'Marker', 'o', 'MarkerEdgeColor',  col_perf(3, :), 'MarkerFaceColor',  col_perf(3, :), 'SizeData', symbolSize, 'MarkerFaceAlpha', 0.6);
                end
    
                symbolSize = 50;
                ha_scatter_correct = scatter(100*e2.Cor, 100*e1.Cor, ...
                    'Marker', '^', 'MarkerEdgeColor',  'k', 'MarkerFaceColor',  col_perf(1, :), 'SizeData', symbolSize, 'MarkerFaceAlpha', 0.6);
                ha_scatter_premature = scatter(100*e2.Pre, 100*e1.Pre, ...
                    'Marker', '^', 'MarkerEdgeColor',  'k', 'MarkerFaceColor',  col_perf(2, :), 'SizeData', symbolSize, 'MarkerFaceAlpha', 0.6);
                ha_scatter_late = scatter(100*e2.Late, 100*e1.Late, ...
                    'Marker', '^', 'MarkerEdgeColor', 'k', 'MarkerFaceColor',  col_perf(3, :), 'SizeData', symbolSize, 'MarkerFaceAlpha', 0.6);
    
                uicontrol('Style', 'text', 'parent', h, 'units', 'normalized', 'position', [0.15 0.95 0.5 0.04],...
                    'string', [Obj.Subject ' | ' Obj.CompExp{1} ' vs ' Obj.CompExp{2}], 'fontweight', 'bold', 'backgroundcolor', [1 1 1], 'fontsize', 8, 'horizontalalignment', 'left');
    
                % Control and DCZ trials should appear as pairs
                xlevel = xlevel+7;
                ylevel = 1.5;
                PlotSize1 = [9 5];
                PlotSize2 = [9 3];
                TimeStep = 0;
    
                col_perf = [85 225 0
                    255 0 0
                    140 140 140]/255;
    
                SessionsCol = [3, 0, 28]/255;
                TrialsCol = [91, 143, 185]/255;
    
                maxHoldTime = Obj.MixedFP(end).*1000 + 1500;
    
                ha_Session = axes('nextplot', 'add', 'unit', 'centimeters', 'position',[xlevel ylevel PlotSize1], 'xlim', [0 3600], ...
                    'xtick',[0:600:3600], 'ylim', [0 100],'ytick', [0:20:100], 'ticklength', [0.02 0.1]);
    
                xlabel('Time (sec)')
                ylabel('Performance')
    
                ylevel = ylevel +9.5; % control sessions
                ha_Trial1 = axes('nextplot', 'add', 'unit', 'centimeters', 'position',[xlevel ylevel PlotSize2], 'xlim', [0 3600], ...
                    'xtick',[], 'ylim', [0 maxHoldTime],'ytick', [0:500:maxHoldTime], 'ticklength', [0.02 0.1]);
                
                htl1 = title([Obj.CompExp{2} ' ' sprintf('%s|', string(Obj.Dates(idxDates2)))], ...
                    'fontname', 'dejavu sans', 'fontsize', 6, 'fontangle', 'italic','color', colors{1});
                htl1.Position(2)=htl1.Position(2)+250;
    
                ylevel = ylevel - 4; % DCZ sessions
                ha_Trial2 = axes('nextplot', 'add', 'unit', 'centimeters', 'position',[xlevel ylevel PlotSize2], 'xlim', [0 3600], ...
                    'xtick',[], 'xticklabel', [], 'ylim', [0 maxHoldTime],'ytick', [0:500:maxHoldTime], 'ticklength', [0.02 0.1]);
    
                htl2 = title([Obj.CompExp{1} ' ' sprintf('%s|', string(Obj.Dates(idxDates1)))], ...
                    'fontname', 'dejavu sans', 'fontsize', 6, 'fontangle', 'italic', 'color', colors{2});
                htl2.Position(2)=htl2.Position(2)+250;
    
                if nargin<2
                    ind = 1;
                end
    
                %  Plot control sessions first
                for k =1:length(idxDates2)
            
                    IndControlSession_k = idxDates2(k);
                    IndChemoSession_k = idxDates1(k);
                    
                    ControlTimeSliding = Obj.SBS(IndControlSession_k,:).progressTime{:};
                    ControlCorrectSliding = Obj.SBS(IndControlSession_k,:).progressPerf{:}.Cor;
                    ControlPrematureSliding = Obj.SBS(IndControlSession_k,:).progressPerf{:}.Pre;
                    ControlLateSliding = Obj.SBS(IndControlSession_k,:).progressPerf{:}.Late;
                    
                    ChemoTimeSliding = Obj.SBS(IndChemoSession_k,:).progressTime{:};
                    ChemoCorrectSliding = Obj.SBS(IndChemoSession_k,:).progressPerf{:}.Cor;
                    ChemoPrematureSliding = Obj.SBS(IndChemoSession_k,:).progressPerf{:}.Pre;
                    ChemoLateSliding = Obj.SBS(IndChemoSession_k,:).progressPerf{:}.Late;
                    
                    hp1 = plot(ha_Session, ControlTimeSliding+TimeStep, ControlCorrectSliding.*100, 'color', col_perf(1, :), 'linewidth', 2);
                    plot(ha_Session, ControlTimeSliding+TimeStep, ControlPrematureSliding.*100, 'color', col_perf(2, :), 'linewidth', 2)
                    plot(ha_Session, ControlTimeSliding+TimeStep, ControlLateSliding.*100, 'color', col_perf(3, :), 'linewidth', 2)
                    
                    hp2 = plot(ha_Session, ChemoTimeSliding+TimeStep, ChemoCorrectSliding.*100, 'color', col_perf(1, :), 'linewidth', 2, 'linestyle', ':');
                    plot(ha_Session, ChemoTimeSliding+TimeStep, ChemoPrematureSliding.*100, 'color', col_perf(2, :), 'linewidth', 2, 'linestyle', ':')
                    plot(ha_Session, ChemoTimeSliding+TimeStep, ChemoLateSliding.*100, 'color', col_perf(3, :), 'linewidth', 2, 'linestyle', ':')
                    
                    line(ha_Session, [TimeStep TimeStep], [0 100],'color', 'k', 'linestyle', '--')
                    
                    IndControlTrials = find(Obj.TBT.Session == Obj.Sessions(IndControlSession_k));
                    IndChemoTrials = find(Obj.TBT.Session == Obj.Sessions(IndChemoSession_k));
                    
                    axes(ha_Trial1)
                    for i =1:length(Obj.MixedFP)
                        
                        iIndControlTrials = IndControlTrials(Obj.TBT.FP(IndControlTrials) == Obj.MixedFP(i));
                        symbolSize = 5+15*(i-1);
                        % plot correct
                        IndCorrectControl= iIndControlTrials(strcmp(Obj.TBT.Outcome(iIndControlTrials), 'Cor'));
                        ha_scatter_correct = scatter(Obj.TBT.TimeElapsed(IndCorrectControl)+TimeStep, Obj.TBT.HT(IndCorrectControl)*1000, ...
                            'Marker', 'o', 'MarkerEdgeColor',  'none', 'MarkerFaceColor',  col_perf(1, :), 'SizeData', symbolSize, 'MarkerFaceAlpha', 0.6);
                        
                        IndPrematureControl= iIndControlTrials(strcmp(Obj.TBT.Outcome(iIndControlTrials), 'Pre'));
                        ha_scatter_premature = scatter(Obj.TBT.TimeElapsed(IndPrematureControl)+TimeStep, Obj.TBT.HT(IndPrematureControl)*1000, ...
                            'Marker', 'o', 'MarkerEdgeColor',  'none', 'MarkerFaceColor',  col_perf(2, :), 'SizeData', symbolSize, 'MarkerFaceAlpha', 0.6);
                        
                        IndLateControl= iIndControlTrials(strcmp(Obj.TBT.Outcome(iIndControlTrials), 'Late'));
                        HoldTimeLate = Obj.TBT.HT(IndLateControl)*1000;
                        HoldTimeLate(HoldTimeLate>maxHoldTime) = maxHoldTime;
                        ha_scatter_late = scatter(Obj.TBT.TimeElapsed(IndLateControl)+TimeStep, HoldTimeLate, ...
                            'Marker', 'o', 'MarkerEdgeColor',  'none', 'MarkerFaceColor',  col_perf(3, :), 'SizeData', symbolSize, 'MarkerFaceAlpha', 0.6);
                    end
            
                    line(ha_Trial1, [TimeStep TimeStep], [0 maxHoldTime], 'color', 'k', 'linestyle', '--');
            
                    axes(ha_Trial2)

                    % Chemo trials
                    for i =1:length(Obj.MixedFP)
                        iIndChemoTrials = IndChemoTrials(Obj.TBT.FP(IndChemoTrials) == Obj.MixedFP(i));
                        symbolSize = 5+15*(i-1);
                        IndCorrectChemo= iIndChemoTrials(strcmp(Obj.TBT.Outcome(iIndChemoTrials), 'Cor'));
                        ha_scatter_correct = scatter(Obj.TBT.TimeElapsed(IndCorrectChemo)+TimeStep, Obj.TBT.HT(IndCorrectChemo)*1000, ...
                            'Marker', 'o', 'MarkerEdgeColor',  'none', 'MarkerFaceColor',  col_perf(1, :), 'SizeData', symbolSize, 'MarkerFaceAlpha', 0.6);
            
                        IndPrematureControl= iIndChemoTrials(strcmp(Obj.TBT.Outcome(iIndChemoTrials), 'Pre'));
                        ha_scatter_premature = scatter(Obj.TBT.TimeElapsed(IndPrematureControl)+TimeStep, Obj.TBT.HT(IndPrematureControl)*1000, ...
                            'Marker', 'o', 'MarkerEdgeColor',  'none', 'MarkerFaceColor',  col_perf(2, :), 'SizeData', symbolSize, 'MarkerFaceAlpha', 0.6);
            
                        IndLateControl= iIndChemoTrials(strcmp(Obj.TBT.Outcome(iIndChemoTrials), 'Late'));
                        HoldTimeLate = Obj.TBT.HT(IndLateControl)*1000;
                        HoldTimeLate(HoldTimeLate>maxHoldTime) = maxHoldTime;
                        ha_scatter_late = scatter(Obj.TBT.TimeElapsed(IndLateControl)+TimeStep, HoldTimeLate, ...
                            'Marker', 'o', 'MarkerEdgeColor',  'none', 'MarkerFaceColor',  col_perf(3, :), 'SizeData', symbolSize, 'MarkerFaceAlpha', 0.6);
                    end
                    line(ha_Trial2, [TimeStep TimeStep], [0 maxHoldTime], 'color', 'k', 'linestyle', '--')
                    TimeStep = TimeStep + max(max(Obj.TBT.TimeElapsed(IndControlTrials)), max(Obj.TBT.TimeElapsed(IndChemoTrials))) + 60;
                end
            
                 legend([hp1, hp2], Obj.CompExp{2}, Obj.CompExp{1},'location', 'best')
                 set(ha_Session, 'xlim', [0 TimeStep], 'xtick', [0:1000:3000])
                 set(ha_Trial1, 'xlim', [0 TimeStep], 'xtick', []);
                 set(ha_Trial2, 'xlim', [0 TimeStep], 'xtick', []);
                 htl1.Position(1)=TimeStep*0.5;
                 htl2.Position(1)=TimeStep*0.5;
            end
            
            function h = mixedFPsPlot(Obj,varargin)
                p = inputParser;
                addRequired(p,'Obj');
                addParameter(p,'shadedExp','DCZ',@ischar);
                parse(p,Obj,varargin{:});
                shadedExp = p.Results.shadedExp;

                set_matlab_default;
                col_perf = [85 225 0
                    255 0 0
                    140 140 140]/255;
                FPColor = [189, 198, 184]/255;
                WhiskerColor = [132, 121, 225]/255;
                ShadeCol = [255, 212, 149]/255;
                
                h = figure(Obj.FigNum); clf(h);
                set(h, 'unit', 'centimeters', 'position',[2 2 30.5 18], 'paperpositionmode', 'auto', 'color', 'w')
                
                % Plot press duration across these sessions
                plotsize1 = [8, 4];
                plotsize4 = [4 3];
                plotsize_rt = [8 4];
                plotsize5 = [2 3]; % for writing information
                plotsize6 = [5 3]; % for writing information
                plotsize3 = [2 3];
    
                plotsize_perf = [3 3];
                plotsize_rt2   = [4 4];
    
                plotsizeIQR = plotsize1;
                plotRTSessions = plotsize1;
                plotsizePDF = [3 3];
    
                StartTime = 0;
                maxDur = 3500/1000; % for  plotting purpose
                maxRT = 2000/1000;
                
                ha(1) = axes;
                xlevel = 2;
                ylevel = 19-plotsize1(2)-2;
                set(ha(1), 'units', 'centimeters', 'position', [xlevel, ylevel, plotsize1], 'nextplot', 'add', ...
                    'ylim', [0 maxDur*1000], 'yscale', 'linear')
                xlabel('Time in session (sec)')
                ylabel('Press duration (msec)')
    
                haRT = axes;
                xlevel = 2;
                ylevel = ylevel - plotsize1(2) - 1.25;
                set(haRT, 'units', 'centimeters', 'position', [xlevel, ylevel, plotsize1], 'nextplot', 'add', ...
                    'ylim', [0 maxRT*1000], 'yscale', 'linear')
                xlabel('Time in session (sec)')
                ylabel('Reaction time (msec)')
    
                haRT2 = axes;
                xlevel = 2;
                ylevel =  ylevel - plotsize1(2) - 1.75;
    
                set(haRT2, 'units', 'centimeters', 'position', [xlevel, ylevel, plotsize_rt], 'nextplot', 'add', ...
                    'ylim', [0 maxRT*1000], 'xlim', [0.5 Obj.nSession+0.5], 'yscale', 'linear', ...
                    'xtick',1:Obj.nSession, ...
                    'xticklabels', string(Obj.Dates), 'XTickLabelRotation', 45);        
                xlabel('Sessions')
                ylabel('Reaction time (msec)')
    
                % Performance score, Cued
                xlevel = 11.5;
                ylevel2 = 19-plotsize1(2)-2;
    
                ha(2) = axes;
                set(ha(2),  'units', 'centimeters', 'position', [xlevel, ylevel2, plotsize1], 'nextplot', 'add', ...
                    'ylim', [-5 100], 'xlim', [0 Obj.TBT.TimeElapsed(end)+Obj.TBT.HT(end)], 'yscale', 'linear')
                ylabel('Performance')
                xlabel('Time in session (sec)')
    
                ylevel3 = ylevel2 - plotsize1(2) - 1.25;
                jitter = 0.25;
    
                ha(3) = axes;
                set(ha(3),  'units', 'centimeters', 'position', [xlevel, ylevel3, plotsize1], 'nextplot', 'add', ...
                    'ylim', [-5 100], 'xlim', [0.5 Obj.nSession+0.5], 'yscale', 'linear', ...
                   'xtick',1:Obj.nSession, ...
                    'xticklabels', string(Obj.Dates));
                xlabel('Sessions')
                ylabel('Performance')
                PerformMarker = '^';
    
                ylevel4 = ylevel3 - plotsize1(2) - 1.75;
                ha_HoldT_Distribution = axes;
                set(ha_HoldT_Distribution,  'units', 'centimeters', 'position', [xlevel, ylevel4, [plotsize1(1) plotsize1(2)]], 'nextplot', 'add', ...
                    'ylim', [0 max(Obj.MixedFP)+1], 'xlim', [0.5 3*Obj.nSession+0.5], 'yscale', 'linear', ...
                    'xtick', 1:3*Obj.nSession, ...
                    'xticklabels', string(Obj.Dates), 'fontsize', 7);
                xlabel('Sessions')
                ylabel('Hold duration (s)')
    
                for k =1:length(Obj.MixedFP)
                    line([Obj.nSession Obj.nSession]*(k)+0.5, [0 max(Obj.Edges_HT)], 'color', 'w', 'linewidth', 1, 'linestyle', '-.')
                end
                
                % plot IQR over time for different FPs
                xlevel = 22;
                ha_HoldT_IQR = axes;
                set(ha_HoldT_IQR,  'units', 'centimeters', 'position', [xlevel, ylevel3, plotsizeIQR], 'nextplot', 'add', ...
                    'ylim', [0 800], 'xlim', [0.5 Obj.nSession+0.5], 'yscale', 'linear', ...
                    'xtick', 1:3*Obj.nSession, ...
                    'xticklabels', string(Obj.Dates), 'fontsize', 7);
                xlabel('Sessions')
                ylabel('IQR (ms)')
    
                IndDCZ = find(contains(Obj.Experiments, shadedExp));
    
                yrange = ylim;
                for k=1:length(Obj.MixedFP)
                    yrange(2) = max([yrange(2),Obj.SBS.HT_IQR_FP(:, k)'.*1000]);
                end
                yrange(2) = yrange(2) * 1.25;
                set(ha_HoldT_IQR,'ylim',yrange);

                if ~isempty(IndDCZ)
                    for j = 1:length(IndDCZ)
                        plotshaded([IndDCZ(j)-2*jitter  IndDCZ(j)+2*jitter],  [yrange(1) yrange(1); yrange(2) yrange(2)], ShadeCol, 0.5);
                    end
                end
    
                for k =1:length(Obj.MixedFP)
                    hp(k) = plot(1:Obj.nSession, Obj.SBS.HT_IQR_FP(:, k).*1000, 'Marker', 'none', 'Color', 'k', 'MarkerFaceColor', 'w', ...
                        'MarkerEdgeColor', 'k','linestyle', '-', 'linewidth', 0.5*k, 'markersize', 5+k*2);
                end
    
                for k =1:length(Obj.MixedFP)
                    symbolSize = 25+25*(k-1);
                    scatter((1:Obj.nSession)', Obj.SBS.HT_IQR_FP(:, k).*1000, ...
                        'MarkerEdgeColor','w',...
                        'MarkerFaceColor',[0.25 0.25 0.25],'Marker', '^','Markerfacealpha', 0.8, ...
                        'linewidth', 1.5, 'SizeData', symbolSize, 'linewidth', 0.5);
                end
    
                % Plot reaction time (median)
                
                 % plot RT over time for different FPs
                xlevel = 22;
                ha_RTs = axes;
                set(ha_RTs,  'units', 'centimeters', 'position', [xlevel, ylevel4, plotsizeIQR], 'nextplot', 'add', ...
                    'ylim', [0 1000], 'xlim', [0.5 Obj.nSession+0.5], 'yscale', 'linear', ...
                    'xtick', 1:3*Obj.nSession, ...
                    'xticklabels', string(Obj.Dates), 'fontsize', 7);
                xlabel('Sessions')
                ylabel('Reaction time (ms)')
    
                RT_Range = [1000 0];
     
                yrange = ylim;
                if ~isempty(IndDCZ)
                    for j = 1:length(IndDCZ)
                        plotshaded([IndDCZ(j)-2*jitter  IndDCZ(j)+2*jitter],  [0 0;10000 10000], ShadeCol, 0.5);
                    end
                end
    
                for k =1:length(Obj.MixedFP)                    
                    RTs = Obj.SBS.RelT_FP(:,k).*1000;
                    RT_Range(1) = min(RT_Range(1), min(RTs));
                    RT_Range(2) = max(RT_Range(2), max(RTs));
                    hp(k) = plot(1:Obj.nSession, RTs, 'Marker', 'none', 'Color', 'k', 'MarkerFaceColor', 'w', ...
                        'MarkerEdgeColor', 'k','linestyle', '-', 'linewidth', 0.5*k, 'markersize', 5+k*2);
                end
    
                set(ha_RTs, 'ylim', [RT_Range(1)*0.8 RT_Range(2)*1.2]);
    
                for k =1:length(Obj.MixedFP)
                    symbolSize = 25+25*(k-1);
                    RTs = Obj.SBS.RelT_FP(:,k).*1000;
                    scatter(1:Obj.nSession, RTs, ...
                        'MarkerEdgeColor','w',...
                        'MarkerFaceColor',[0.25 0.25 0.25],'Marker', '^','Markerfacealpha', 0.8, ...
                        'linewidth', 1.5, 'SizeData', symbolSize, 'linewidth', 0.5);
                end
                
                % Response PDF
                xlevel = 20.5;
                EarlyColor = [62, 84, 172]/255;
                LateColor = [249, 74, 41]/255;
                HTpdf_FPall = [];
                for k=1:length(Obj.MixedFP)
                    HTpdf_FPall = [HTpdf_FPall,Obj.CBC.(['HTpdf_FP',num2str(k)])];
                end
                MaxPDF = max(HTpdf_FPall,[],'all');
                for k = 1:length(Obj.MixedFP)
                    ha_pdf_progress(k) = axes;
                    xlevel_k = xlevel + (plotsizePDF(1)+ 0.25)*(k-1);
                    set(ha_pdf_progress(k), 'units', 'centimeters', 'position', [xlevel_k, ylevel2+0.5, plotsizePDF], 'nextplot', 'add', ...
                        'ylim', [0 MaxPDF*1.1],...
                        'xlim', [0 max(Obj.MixedFP).*1000+1000],'xtick',0:500:max(Obj.Edges_HT)*1000, 'yscale', 'linear');
                    hp1 = plot(ha_pdf_progress(k), Obj.Bins_HT*1000, Obj.CBC(Obj.CBC.Customization=="EarlyProgress",:).(['HTpdf_FP',num2str(k)]), ...
                        'color', EarlyColor, 'linewidth', 1.5);
                    hp2 = plot(ha_pdf_progress(k), Obj.Bins_HT*1000, Obj.CBC(Obj.CBC.Customization=="LateProgress",:).(['HTpdf_FP',num2str(k)]), ...
                        'color', LateColor, 'linewidth', 1.5);
                    
                    line([Obj.MixedFP(k).*1000 Obj.MixedFP(k).*1000], [0 MaxPDF*1.1], 'color', [0.5 0.5 0.5], 'linewidth', 1, 'linestyle', ':')
                    
                    if k >1
                        set(ha_pdf_progress(k), 'yticklabel', [])
                    else
                        ylabel('PDF (1/s)')
                        xlabel('Hold dur (ms)')
                    end
                    
                    if k == length(Obj.MixedFP)
                        hp_early = hp1;
                        hp_late = hp2;
                    end
                end
               
                legend([hp_early, hp_late], 'Early', 'Late', 'Box','off', 'Location','northeast')
              
                % Press duration y range
                Lneg                   = -250; % for plotting response time
                PressDurRange = [Lneg, max(Obj.MixedFP).*1000+2000];
                MarkerAlpha = 0.4;
                
                CorrectSessions = [];
                PrematureSessions = [];
                LateSessions = [];
                
                % for computing reaction time distribution
                RT_FPs              =        [];
                RT_FPs_Types   =        [];
                
                % For tracking sessions
                FirstSession            =         0;
                
                % Plot post lesion sessions
                % make shade illustrate postion lesion sessions
                % Plot Lesions
                StartTime = 0;
                HoldTDistributionAll = cell(1, length(Obj.MixedFP));
                HTpdf_FPsbs = [];
                for k=1:length(Obj.MixedFP)
                    HTpdf_FPsbs = [HTpdf_FPsbs,Obj.SBS.(['HTpdf_FP',num2str(k)])];
                end
                maxHoldT_PDF = max(HTpdf_FPsbs,[],'all');
                
                for i =1:Obj.nSession
                    for k =1:length(Obj.MixedFP)
                        HoldTDistributionAll{k} = [HoldTDistributionAll{k} Obj.SBS.(['HTpdf_FP',num2str(k)])(i,:)'];
                    end
                    
                    Treatment = 0;
                    if ~isempty(Obj.Experiments)
                        if contains(Obj.Experiments{i}, shadedExp)
                            Treatment = 1;
                        end
                    end
                    
                    iTrialsIndx                     = (Obj.TBT.Session==Obj.Sessions(i))';
                    iPressTimes                     = Obj.TBT.TimeElapsed(iTrialsIndx)';
                    iReleaseTimes                   = (Obj.TBT.TimeElapsed(iTrialsIndx) + Obj.TBT.HT(iTrialsIndx))';
                    iPressDurs                      = Obj.TBT.HT(iTrialsIndx)';
                    iRTs                            = Obj.TBT.RelT(iTrialsIndx)';
                    iRTs_Org                        = iRTs;
                    iRTs(iRTs>maxRT)                = maxRT;
                    iPressDurs(iPressDurs>maxDur)   = maxDur;
                    iOutcome                        = Obj.TBT.Outcome(iTrialsIndx)';
                    iStage                          = ones(1,sum(iTrialsIndx)); % warm-up does not exist
                    iFP                             = Obj.TBT.FP(iTrialsIndx)';
                    indPerformanceSliding           = i;
    
                    % Check if this is a Chemo session
                    set(ha(1), 'ylim', PressDurRange, 'xlim', [0 iReleaseTimes(end)+StartTime], 'yscale', 'linear');
                    set(ha(2), 'ylim', [-5 100], 'xlim', [0 iReleaseTimes(end)+StartTime], 'yscale', 'linear', 'xtick', []);
                    set(haRT, 'xlim', [0 iReleaseTimes(end)+StartTime])
    
                    % draw shades
                    if Treatment
                        axes(ha(1))
                        plotshaded([StartTime StartTime + iReleaseTimes(end)], [PressDurRange(1) PressDurRange(1); PressDurRange(2) PressDurRange(2)], ShadeCol, 0.5);
                        axes(ha(2))
                        plotshaded([StartTime StartTime + iReleaseTimes(end)], [-5 -5; 100 100], ShadeCol, 0.5);
                        axes(ha(3))
                        plotshaded([i-2*jitter  i+2*jitter], [-5 -5; 100 100], ShadeCol, 0.5);
                        axes(haRT)
                        plotshaded([StartTime StartTime + iReleaseTimes(end)], [0 0; maxRT*1000 maxRT*1000], ShadeCol, 0.5);
                        axes(haRT2)
                        plotshaded([i-2*jitter  i+2*jitter], [0 0; maxRT*1000 maxRT*1000], ShadeCol, 0.5);
                    end
    
                    % mark a new session
                    line(ha(1), [StartTime StartTime], [0 maxDur*1000], ...
                        'linestyle', ':' ,'color', [0.6 0.6 0.6],'linewidth', 1);
                    line(haRT, [StartTime StartTime], [0 maxRT*1000], ...
                        'linestyle', ':' ,'color', [0.6 0.6 0.6],'linewidth', 1);
                    line(ha(2), [StartTime StartTime], [-5 100], ...
                        'linestyle', ':' ,'color', [0.6 0.6 0.6],'linewidth', 1);
    
                    if i >1
                        line(ha(3), [i i]-jitter*2, [-5 100], ...
                            'linestyle', ':' ,'color', [0.6 0.6 0.6],'linewidth', 1);
                    end
    
                    % plot press times
                    line(ha(1), [iPressTimes; iPressTimes]+StartTime, [Lneg; 0], 'color', 'b'); % all press times
    
                    % Plot premature responses
                    for k =1:length(Obj.MixedFP)
                        symbolSize = 5+10*(k-1);
                        ind_premature_presses = strcmp(iOutcome, 'Pre') & iFP == Obj.MixedFP(k) & iStage == 1;
                        scatter(ha(1),iPressTimes(ind_premature_presses)+StartTime, ...
                            1000*iPressDurs(ind_premature_presses), ...
                            25, col_perf(2, :), 'o','Markerfacealpha', 0.8, 'linewidth', 1, 'SizeData', symbolSize, 'linewidth', 0.5);
                    end
    
%                     %  Plot dark responses
%                     ind_dark_presses = strcmp(iOutcome, 'Dark') & iStage == 1;
%                     scatter(ha(1),iPressTimes(ind_dark_presses)+StartTime, ...
%                         1000*iPressDurs(ind_dark_presses), ...
%                         8, 'k',  '+', 'filled','Markerfacealpha', 0.6, 'linewidth', 0.5, 'MarkerEdgeColor','none');
    
                    % Plot late and correct responses
                    for k =1:length(Obj.MixedFP)
                        symbolSize = 5+10*(k-1);
                        ind_late_presses = strcmp(iOutcome, 'Late') & iFP == Obj.MixedFP(k) & iStage == 1;
                        scatter(ha(1), iPressTimes(ind_late_presses)+StartTime, ...
                            1000.*iPressDurs(ind_late_presses), ...
                            25, col_perf(3, :), 'o','Markerfacealpha', 0.8, 'linewidth', 1, 'SizeData', symbolSize, 'linewidth', 0.5);
                        % also plot reaction time
                        scatter(haRT, iPressTimes(ind_late_presses)+StartTime, ...
                            1000.*iRTs(ind_late_presses), ...
                            25, col_perf(3, :), 'o','Markerfacealpha', 0.8, 'linewidth', 1, 'SizeData', symbolSize, 'linewidth', 0.5);
    
                        ind_correct_presses = strcmp(iOutcome, 'Cor') & iFP == Obj.MixedFP(k) & iStage == 1;
                        scatter(ha(1),iPressTimes(ind_correct_presses)+StartTime, ...
                            1000.*iPressDurs(ind_correct_presses), ...
                            25, col_perf(1, :), 'o','Markerfacealpha', 0.8, 'linewidth', 1, 'SizeData', symbolSize, 'linewidth', 0.5);
    
                        % also plot reaction time
                        scatter(haRT, iPressTimes(ind_correct_presses)+StartTime, ...
                            1000.*iRTs(ind_correct_presses), ...
                            25, col_perf(1, :), 'o','Markerfacealpha', 0.8, 'linewidth', 1, 'SizeData', symbolSize, 'linewidth', 0.5);
                    end
    
                    ind_rt_presses = (strcmp(iOutcome, 'Cor') | strcmp(iOutcome, 'Late')) & iStage == 1;
    
                    if sum(ind_rt_presses)>0
                        RT_FPs          = [RT_FPs 1000*iRTs_Org(ind_rt_presses)];
                        RT_FPs_Types    = [RT_FPs_Types repmat(i, 1, sum(ind_rt_presses))];
                    else
                        RT_FPs          = [RT_FPs rand(1, 100)];
                        RT_FPs_Types    = [RT_FPs_Types repmat(i, 1,100)];
                    end
    
                    % plot performance over time
                    plot(ha(2),  Obj.SBS.progressTime{indPerformanceSliding} + StartTime, ...
                        100.*Obj.SBS.progressPerf{indPerformanceSliding}.Cor, 'linewidth', 1, 'Color',col_perf(1, :), ...
                        'marker', 'none', 'linestyle', '-', 'markersize', 4)
    
                    plot(ha(2),  Obj.SBS.progressTime{indPerformanceSliding} + StartTime, ...
                        100.*Obj.SBS.progressPerf{indPerformanceSliding}.Pre, 'linewidth', 1, 'Color',col_perf(2, :));
    
                    plot(ha(2),  Obj.SBS.progressTime{indPerformanceSliding} + StartTime, ...
                        100.*Obj.SBS.progressPerf{indPerformanceSliding}.Late, 'linewidth', 1, 'Color',col_perf(3, :));
    
                    % plot performance over session
                    CorrectSessions     = [CorrectSessions; zeros(1, 1+length(Obj.MixedFP))];
                    PrematureSessions   = [PrematureSessions; zeros(1, 1+length(Obj.MixedFP))];
                    LateSessions        = [LateSessions; zeros(1, 1+length(Obj.MixedFP))];
    
                    axes(ha(3))
    
                    for k =1:length(Obj.MixedFP)
    
                        symbolSize = 20+25*(k-1);
                        iFP = Obj.MixedFP(k);
                        xloc = i-jitter+jitter*(k-1);
                        
                        CorrPerc =  Obj.SBS.Cor_FP(i,k).*100;
                        scatter(xloc , CorrPerc,  'Marker', PerformMarker, 'SizeData', symbolSize, 'LineWidth', 1, ...
                            'MarkerFaceColor', col_perf(1,:), 'MarkerEdgeColor', 'none', 'MarkerFaceAlpha',MarkerAlpha);
    
                        PremPerc =  Obj.SBS.Pre_FP(i,k).*100;
                        scatter(xloc , PremPerc,  'Marker', PerformMarker, 'SizeData', symbolSize, 'LineWidth', 1, ...
                            'MarkerFaceColor', col_perf(2,:), 'MarkerEdgeColor', 'none', 'MarkerFaceAlpha', MarkerAlpha);
    
                        LatePerc =  Obj.SBS.Late_FP(i,k).*100;
                        scatter(xloc , LatePerc,  'Marker', PerformMarker, 'SizeData', symbolSize, 'LineWidth', 1, ...
                            'MarkerFaceColor', col_perf(3,:), 'MarkerEdgeColor', 'none', 'MarkerFaceAlpha', MarkerAlpha);
    
                        CorrectSessions(end, k)     = CorrPerc;
                        PrematureSessions(end, k)   = PremPerc;
                        LateSessions(end, k)        = LatePerc;
                    end

                    CorrectSessions(end, k+1)   = Obj.SBS.Cor(i).*100;
                    PrematureSessions(end, k+1) = Obj.SBS.Pre(i).*100;
                    LateSessions(end, k+1)      = Obj.SBS.Late(i).*100;
    
                    StartTime = iReleaseTimes(end) + StartTime + 60;
                end

                axes(ha_HoldT_Distribution)
                imagesc(1:Obj.nSession*3, Obj.Bins_HT,  cell2mat(HoldTDistributionAll), [0 maxHoldT_PDF*1.2]);
                colormap(turbo);
                hbar = colorbar;
                xlevel = 11.5;
                set(hbar, 'units', 'centimeters', 'position', [xlevel+plotsize1(1)+0.1, ylevel4, [0.2 plotsize1(2)]]);
                hbar.Label.String = 'PDF (1/sec)';
    
                for k =1:length(Obj.MixedFP)
                    text(0+Obj.nSession*(k-1)+1, max(Obj.MixedFP)+1-0.1, [num2str(Obj.MixedFP(k)) ' s'], 'fontname', 'dejavu sans', 'fontsize', 8, 'color', 'w');
                    if ~isempty(IndDCZ)
                        for j = 1:length(IndDCZ)
                            arrow([IndDCZ(j)+Obj.nSession*(k-1), 0], [IndDCZ(j)+Obj.nSession*(k-1) 0.15], ...
                                'color', ShadeCol, 'linewidth', 2, 'Length',3, 'TipAngle', 35);
                            pos = [IndDCZ(j)+Obj.nSession*(k-1)-0.5, 0, 1, max(Obj.MixedFP)+1];
                            rectangle('Position',pos, 'EdgeColor', ShadeCol, 'linewidth', 0.5, 'linestyle', ':')
                        end
                    end
                    line(ha_HoldT_Distribution, [Obj.nSession Obj.nSession]*(k)+0.5, [0 max(Obj.Edges_HT)], 'color', 'w', 'linewidth', 1, 'linestyle', '-.')
                end
    
                % add average perfromance score: AllPreLesionSessions / AllPostLesionSessions
                hp_correct = plot(ha(3), 1:Obj.nSession, CorrectSessions(:, end), ...
                    'linewidth', 2.5, 'color', col_perf(1, :), 'marker', '.', 'markersize', 10);
                hp_premature = plot(ha(3), 1:Obj.nSession, PrematureSessions(:, end), ...
                    'linewidth', 2.5, 'color', col_perf(2, :), 'marker', '.', 'markersize', 10);
                hp_late = plot(ha(3), 1:Obj.nSession, LateSessions(:, end), ...
                    'linewidth', 2.5, 'color', col_perf(3, :), 'marker', '.', 'markersize', 10);
    
                % reaction time violing plot
                axes(haRT2)
                pos_org = get(haRT2, 'Position');
                hVio1 = violinplot(RT_FPs,  RT_FPs_Types, 'Width', 0.4, 'ViolinAlpha', 0.2, 'ShowWhiskers', false, 'EdgeColor', [0 0 0], 'BoxColor', [253, 138, 138]/255, 'ViolinColor', [0.6 0.6 0.6]);
                for iv =1:length(hVio1)
                    hVio1(iv).EdgeColor = [0 0 0];
                    hVio1(iv).WhiskerPlot.Color = WhiskerColor;
                    hVio1(iv).WhiskerPlot.LineWidth = 1.5;
                    hVio1(iv).ScatterPlot.MarkerFaceColor = 'k';
                    hVio1(iv).ScatterPlot.SizeData = 10;
                    hVio1(iv).ViolinPlot.FaceColor = [0.8 0.8 0.8];
                    hVio1(iv).BoxColor=[253, 138, 138]/255;
                    hVio1(iv).BoxWidth = 0.03;
                end
    
                set(haRT2, 'Position', pos_org, 'xlim', [0 Obj.nSession+1], 'xtick',[1:Obj.nSession], ...
                    'xticklabel',string(Obj.Dates), ...
                    'ylim', [0 maxRT*1000])
    
                hui_1 = uicontrol('Style', 'text', 'parent', h, 'units', 'normalized', 'position', [0.1 0.965 0.2 0.03],...
                    'string',  ['Subject: ' Obj.Subject], 'fontweight', 'bold', ...
                    'backgroundcolor', [1 1 1], 'HorizontalAlignment', 'left' , 'fontname', 'dejavu sans' );
                
                hui_2 = uicontrol('Style', 'text', 'parent', h, 'units', 'normalized', 'position', [0.5 0.965 0.3 0.03],...
                    'string', ['Protocol: ' Obj.Tasks{1}], 'fontweight', 'bold', ...
                    'backgroundcolor', [1 1 1], 'HorizontalAlignment', 'left' , 'fontname', 'dejavu sans');
                
                hui_3 = uicontrol('Style', 'text', 'parent', h, 'units', 'normalized', 'position', [0.3 0.965 0.2 0.03],...
                    'string',  ['Group: ' Obj.Group], 'fontweight', 'bold', ...
                    'backgroundcolor', [1 1 1], 'HorizontalAlignment', 'left' , 'fontname', 'dejavu sans' );
                
                if any(IndDCZ)
                    hui_4 = uicontrol('Style', 'text', 'parent', h, 'units', 'normalized', 'position', [0.8 0.965 0.2 0.03],...
                        'string', ['Shade: ' shadedExp], 'fontweight', 'bold', ...
                        'backgroundcolor', [1 1 1], 'HorizontalAlignment', 'left' , 'fontname', 'dejavu sans');
                end
            end

            function h = learningPlot(Obj)
                tbt = Obj.TBT;
                sbs = Obj.SBS;

                if any(contains(unique(tbt.Task),{'Wait1'}))
                    rtLim = [0,2];
                else
                    rtLim = [0,0.6];
                end
                if any(contains(unique(tbt.Task),'3FPs'))
                    plot3FP = true;
                else
                    plot3FP = false;
                end
                if isempty(figSize)
                    figSize = [9 16];
                end
                
                % TrialNum & dark ratio
                g(1,1) = gramm('x',cellstr(sbs.DateTime,'MMdd'),'y',sbs.nTrial,'color',sbs.rTrial);
                g(1,1).facet_grid(cellstr(sbs.TrialType), cellstr(sbs.Task),'scale','free_x','space','free_x');
                g(1,1).geom_point(); g(1,1).set_point_options('base_size',6);
                g(1,1).geom_line();  g(1,1).set_line_options('base_size',2);
                g(1,1).axe_property('ylim',[0 400],'xticklabels', {}, 'XGrid', 'on', 'YGrid', 'off',...
                    'tickdir','out');
                g(1,1).set_names('x',{}, 'y', 'Trials','column', '','color','Trial%');
                g(1,1).set_continuous_color('colormap','copper','CLim',[0,1]);
                g(1,1).set_order_options('column',0,'x',0);
                g(1,1).set_layout_options('Position',[0 0.87 0.9 0.13],'legend_position',[0.89 0.815 0.1 0.1]);
                % Performance
                SBSp = stack(sbs,{'Cor','Pre','Late'});
                g(2,1) = gramm('X', cellstr(SBSp.DateTime,'MMdd'), 'Y',SBSp.Cor_Pre_Late, 'color',SBSp.Cor_Pre_Late_Indicator);
                g(2,1).facet_grid(cellstr(SBSp.TrialType), cellstr(SBSp.Task), 'scale', 'free_x','space','free_x', 'column_labels', false);
                g(2,1).geom_hline('yintercept',0.7,'style','k:');
                g(2,1).geom_point(); g(2,1).set_point_options('base_size',6);
                g(2,1).geom_line();  g(2,1).set_line_options('base_size',2);
                g(2,1).axe_property('ylim', [0 1], 'xticklabels', {}, 'XGrid', 'on', 'YGrid', 'off',...
                    'tickdir','out');
                g(2,1).set_names('x',{}, 'y', 'Performance','color','');
                g(2,1).set_color_options('map',cCPL,'n_color',3,'n_lightness',1);
                g(2,1).set_order_options('column',0,'x',0,'color',{'Cor','Pre','Late'});
                g(2,1).set_layout_options('Position',[0 0.57 0.9 0.3],'legend_position',[0.89 0.74 0.08 0.1]);
                % RT
                g(3,1) = gramm('X',cellstr(tbt.DateTime,'MMdd'),'Y',tbt.RT,'subset',contains(tbt.Outcome,'Cor'));
                g(3,1).facet_grid(cellstr(tbt.TrialType), cellstr(tbt.Task), 'scale', 'free_x','space','free_x', 'column_labels',false);
                % g(3,1).stat_violin('half',true,'normalization','area','fill','edge','dodge',0,'width',0.7);
                g(3,1).stat_boxplot('width', 0.5,'notch',false);
                g(3,1).set_point_options('base_size',2);
                g(3,1).set_color_options('map',cBlue,'n_color',1,'n_lightness',1);
                g(3,1).axe_property('ylim', rtLim, 'xticklabels', {},'XTickLabelRotation', 90, 'XGrid', 'on', 'YGrid', 'off',...
                    'tickdir','out');
                g(3,1).set_names('x',{}, 'y', 'RT(s)','column', '','color','FP(s)');
                g(3,1).set_order_options('column',0,'x',0);
                g(3,1).set_layout_options('Position',[0 0.37 0.9 0.2]);
                % Trial2Criterion or Performance by 3FP
                if ~plot3FP
                    % pre-processed
                    SBS_t = stack(sbs,{'t2mFP','t2mRW'});
                    SBS_c = stack(sbs,{'maxFP','minRW'});
                    SBS_t.t2mFP_t2mRW_Indicator = categorical(erase(cellstr(SBS_t.t2mFP_t2mRW_Indicator),{'t2m'}));
                    SBS_c.maxFP_minRW_Indicator = categorical(erase(cellstr(SBS_c.maxFP_minRW_Indicator),{'min','max'}));
                    
                    g(4,1) = gramm('X',cellstr(SBS_c.DateTime,'MMdd'),'Y',SBS_c.maxFP_minRW,...
                        'linestyle',SBS_c.maxFP_minRW_Indicator);
                    g(4,1).facet_grid(cellstr(SBS_c.TrialType), cellstr(SBS_c.Task), 'scale', 'free_x','space','free_x', 'column_labels',false);
                    g(4,1).axe_property('ylim', [0.5 2], 'xticklabels', {}, 'XGrid', 'on', 'YGrid', 'off','tickdir','out');
                    g(4,1).set_names('x',{}, 'y','BestPerf','column','','color','','linestyle','');
                    g(4,1).geom_point(); g(4,1).set_point_options('base_size',6);
                    g(4,1).geom_line();  g(4,1).set_line_options('base_size',2,'style',{'-',':'});
                    g(4,1).set_color_options('map',cGray,'n_color',1,'n_lightness',1);
                    g(4,1).set_order_options('column',0,'x',0,'line',{'FP','RW'});
                    g(4,1).set_layout_options('Position',[0 0.2 0.9 0.17],'legend_position',[0.89,0.28,0.24,0.1]);
                    
                    g(5,1) = gramm('X',cellstr(SBS_t.DateTime,'MMdd'),'Y',SBS_t.t2mFP_t2mRW,...
                        'linestyle',SBS_t.t2mFP_t2mRW_Indicator);
                    g(5,1).facet_grid(cellstr(SBS_t.TrialType), cellstr(SBS_t.Task), 'scale', 'free_x','space','free_x', 'column_labels',false);
                    g(5,1).axe_property('ylim', [40 200], 'XTickLabelRotation', 90, 'XGrid', 'on', 'YGrid', 'off','tickdir','out');
                    g(5,1).set_names('x',{}, 'y','Trials2BestPerf','column','','color','','linestyle','');
                    g(5,1).geom_point(); g(5,1).set_point_options('base_size',6);
                    g(5,1).geom_line();  g(5,1).set_line_options('base_size',2,'style',{'-',':'});
                    g(5,1).set_color_options('map',cGray,'n_color',1,'n_lightness',1);
                    g(5,1).set_order_options('column',0,'x',0,'line',{'FP','RW'});
                    g(5,1).set_layout_options('Position',[0 0.0 0.9 0.2],'legend_position',[0.89,0.12,0.1,0.1]);
                    g(5,1).no_legend;
                else
                    SBS_3c = stack(splitvars(sbs,'Cor_FP','NewVariableNames',{'CorS','CorM','CorL'}),{'CorS','CorM','CorL'});
                    g(4,1) = gramm('X',cellstr(SBS_3c.DateTime,'MMdd'),'Y',SBS_3c.CorS_CorM_CorL,...
                        'linestyle',SBS_3c.CorS_CorM_CorL_Indicator,'color',SBS_3c.CorS_CorM_CorL_Indicator);
                    g(4,1).facet_grid(cellstr(SBS_3c.TrialType), cellstr(SBS_3c.Task), 'scale', 'free_x','space','free_x', 'column_labels',false);
                    g(4,1).geom_point(); g(4,1).set_point_options('base_size',4);
                    g(4,1).geom_line();  g(4,1).set_line_options('base_size',1.5,'style',{':','-.','-'});
                    g(4,1).geom_hline('yintercept',0.7,'style','k:');
                    g(4,1).axe_property('ylim', [0 1], 'xticklabels', {}, 'XGrid', 'on', 'YGrid', 'off','tickdir','out');
                    g(4,1).set_names('x',{}, 'y','Accuracy','column','','color','','linestyle','FP');
                    g(4,1).set_color_options('map',c3FPs,'n_color',3,'n_lightness',1);
                    g(4,1).set_order_options('column',0,'x',0,'linestyle',{'CorS','CorM','CorL'},'color',{'CorS','CorM','CorL'});
                    g(4,1).set_layout_options('Position',[0 0.20 0.9 0.17],'legend_position',[0.89,0.28,0.1,0.1]);
                    g(4,1).no_legend;
                    
                    g(5,1) = gramm('X',cellstr(tbt.DateTime,'MMdd'),'Y',tbt.RT,...
                        'color',tbt.FP,...
                        'subset',(tbt.FP==0.5 | tbt.FP==1.0 | tbt.FP==1.5) & tbt.Outcome=="Cor");
                    g(5,1).facet_grid(cellstr(tbt.TrialType), cellstr(tbt.Task), 'scale', 'free_x','space','free_x', 'column_labels', false);
                    g(5,1).stat_summary('type', @(x)compute_stat_summary(x,'quartile'),'geom',{'errorbar','point'},'dodge',0.6);
                    g(5,1).set_point_options('base_size',3);
                    g(5,1).set_line_options('base_size',1.2);
                    g(5,1).axe_property('ylim', [0 0.6], 'XGrid', 'on', 'YGrid', 'off','XTickLabelRotation',90, 'tickdir','out');
                    g(5,1).set_names('x',{}, 'y', 'RT(s) Quartile','color','FP(s)');
                    g(5,1).set_color_options('map',c3FPs,'n_color',3,'n_lightness',1);
                    g(5,1).set_order_options('column',0,'x',0,'color',1);
                    g(5,1).set_layout_options('Position',[0 0.0 0.9 0.2],'legend_position',[0.89,0.09,0.1,0.1]);
                end
                g.set_title(append(Obj.Subject,': Learning Curve'));
                g.set_text_options('base_size',fontAxesSz,'label_scaling',fontLablSz./fontAxesSz,...
                    'legend_scaling',1.1,'legend_title_scaling',1.2,...
                    'facet_scaling',fontTitlSz/fontAxesSz,...
                    'title_scaling',fontTitlSz/fontAxesSz,'big_title_scaling',fontTitlSz/fontAxesSz+0.1);
                
                h = figure(2);clf(h);
                set(h,'Name','LearningFig','unit','centimeters',...
                    'position',[1 1 figSize],'paperpositionmode','auto');
                g.draw();

                % modify
                hp = findobj(g(3,1).facet_axes_handles,'Type','Line');
                set(hp,'MarkerSize',2);
            end

            function h = progressPlot(Obj)
                
                tbt = Obj.TBT(Obj.TBT.Experiment ~= 'reject', :);
                % figure position & axes
                xstart = 1.5; ystart = 1.3;
                xsep = 0.5; ysep = 1.2;
                if isempty(figSize)
                    figSize = [3, 3];
                end
                axesSz = [(figSize(1)+xsep).*Obj.nSession-xsep figSize(2)];
                figPos = [2 2 ...
                    xstart+axesSz(1)+xsep...
                    ystart+(axesSz(2)+ysep).*3];
                tickLen = [0.15 0.25]; % cm
                
                
                % Merge time as x axis
                sepSess = 300;
                [~,ia,ic] = unique(tbt.Date,'last');
                curTime = cumsum(tbt.TimeElapsed(ia)+sepSess);
                timeSep = (curTime - sepSess./2)./60;
                curTime = [0;curTime(1:end-1)];
                tem = tbt.TimeElapsed; % TimeElapsedMerge
                for k=1:length(ia)
                    tem(ic==k) = tem(ic==k) + curTime(k);
                end
                tem = tem./60; % min
                tbt = addvars(tbt,tem,'After','TimeElapsed','NewVariableNames','TimeElapsedMerge');
                
                if ~isempty(expName)
                    idx = find(tbt.Session(ia)<0,1,'last');
                    switchTime = (tbt.TimeElapsedMerge(ia(idx)) + sepSess./120);
                end
                                % index
                sessName = unique(tbt.Date);
                idxCor = tbt.Outcome == "Cor";
                idxPre = tbt.Outcome == "Pre";
                idxLate = tbt.Outcome == "Late";
                idxW1 = tbt.Task == "Wait1";
                idxW2 = tbt.Task == "Wait2";
                % limit
                tLim = [0 max(tbt.TimeElapsedMerge)+sepSess/60];
                htLim = [0 2500];
                rtLim = [0 1000];
                winSz = 30;
                stepSz = 15;
                
                %
                h = figure(2);clf(h);
                set(h, 'unit', 'centimeters', 'position',figPos,...
                    'paperpositionmode', 'auto', 'color', 'w')
                uicontrol(h,'Style', 'text', 'units', 'centimeters',...
                        'position', [figPos(3)/2-4,figPos(4)-ysep*0.66,8,0.5],...
                        'string', append(tbt.Subject,' / ', num2str(min(tbt.Date)),'-',num2str(max(tbt.Date))),...
                        'fontsize', fontTitlSz, 'fontweight', 'bold','backgroundcolor', [1 1 1]);
                
                % Hold time - Time
                ha1 = axes;
                set(ha1, 'units', 'centimeters', 'position', [xstart,ystart,axesSz],...
                    'nextplot', 'add', 'ylim', htLim, 'xlim', tLim, 'tickdir','out',...
                    'TickLength', [tickLen(1)/max(axesSz),tickLen(2)/max(axesSz)], 'fontsize',fontAxesSz);
                xlabel('Time (min)','FontSize',fontLablSz)
                ylabel('Hold time (ms)','FontSize',fontLablSz)
                
                if ~isempty(idxW1)
                    fillCriterion(tbt(idxW1,:),[1.5,2],htLim,cCyan)
                end
                if ~isempty(idxW2)
                    fillCriterion(tbt(idxW2,:),[1.5,0.6],htLim,cCyan)
                end
                line([timeSep timeSep],htLim,'color','k','linewidth',1,'linestyle','--');
                if ~isempty(expName)
                    line([switchTime switchTime],htLim,'color',cRed,'linewidth',2,'linestyle','-');
                end

                modiHT = tbt.HT.*1000; modiHT(modiHT>htLim(2)) = htLim(2);
                line([tbt.TimeElapsedMerge,tbt.TimeElapsedMerge],[htLim(1),htLim(1)+diff(htLim)/10],...
                    'color',cBlue,'linewidth',0.4);
                scatter(tbt.TimeElapsedMerge(idxCor),modiHT(idxCor),15,cCPL(1,:),...
                    'MarkerEdgeAlpha',0.7,'LineWidth',1);
                scatter(tbt.TimeElapsedMerge(idxPre),modiHT(idxPre),15,cCPL(2,:),...
                    'MarkerEdgeAlpha',0.7,'LineWidth',1);
                scatter(tbt.TimeElapsedMerge(idxLate),modiHT(idxLate),15,cCPL(3,:),...
                    'MarkerEdgeAlpha',0.7,'LineWidth',1);

                % Sliding RT - Time
                ha2 = axes;
                set(ha2, 'units', 'centimeters', 'position', [xstart,ystart+(axesSz(2)+ysep),axesSz],...
                    'nextplot', 'add', 'ylim', rtLim, 'xlim', tLim,'tickdir','out',...
                    'TickLength', [tickLen(1)/max(axesSz),tickLen(2)/max(axesSz)],'fontsize',fontAxesSz);
%                 xlabel('Time (min)','FontSize',fontLablSz);
                ylabel('Reaction time (ms)','FontSize',fontLablSz);
                
                if ~isempty(idxW1)
                    fillCriterion(tbt(idxW1,:),[1.5,2],htLim,cCyan)
                end
                if ~isempty(idxW2)
                    fillCriterion(tbt(idxW2,:),[1.5,0.6],htLim,cCyan)
                end
                modiRT = (tbt.HT - tbt.FP).*1000;
                modiRT(modiRT>rtLim(2)) = rtLim(2);
                modiRT(modiRT<rtLim(1)) = rtLim(1);
                scatter(tbt.TimeElapsedMerge(idxCor),modiRT(idxCor),15,cCPL(1,:),...
                    'MarkerFaceAlpha',0.5,'MarkerEdgeAlpha',0.5,'LineWidth',0.5);
                scatter(tbt.TimeElapsedMerge(idxLate),modiRT(idxLate),15,cCPL(3,:),...
                    'MarkerFaceAlpha',0.5,'MarkerEdgeAlpha',0.5,'LineWidth',0.5);
                line([timeSep timeSep],rtLim,'color','k','linewidth',1,'linestyle','--');
                if ~isempty(expName)
                    line([switchTime switchTime],rtLim,'color',cRed,'linewidth',2,'linestyle','-');
                    text(switchTime, 1.08*rtLim(2), expName{1}+" vs. "+expName{2}, ...
                       'FontSize', fontTitlSz, 'Color', cRed, ...
                       'FontWeight','bold','HorizontalAlignment','center');
                end

                for j=1:length(sessName)
                    idxSess = tbt.Date==sessName(j);
                    T = tbt(idxSess,:);
                
                    rtSess = T.HT - T.FP;
                    rtCL = rtSess; rtCL(T.Outcome=="Pre") = NaN;
                    rtC = rtSess; rtC(T.Outcome=="Pre" | T.Outcome=="Late") = NaN;
                    
                    [xc,yc] = calMovAVG(T.TimeElapsedMerge,rtC,...
                        'winSize',winSz,'stepSize',stepSz,'tarStr','Cor','avgMethod','mean');
                    lr1 = plot(xc, yc.*1000, 'o', 'linestyle', '-', 'color', 'k', ...
                        'markersize', 5, 'linewidth', 1.2, 'markerfacecolor', 'k',...
                        'markeredgecolor', 'w');
                
                    [xcl,ycl] = calMovAVG(T.TimeElapsedMerge,rtCL,...
                        'winSize',winSz,'stepSize',stepSz,'tarStr','Cor','avgMethod','mean');
                    lr2 = plot(xcl, ycl.*1000, 'o', 'linestyle', '-', 'color', cBrown, ...
                        'markersize', 5, 'linewidth', 1.2, 'markerfacecolor', cBrown,...
                        'markeredgecolor', 'w');
                end
                le2 = legend([lr1 lr2],{'Cor','Cor+Late'},'units','centimeters',...
                    'Position',[xstart+axesSz(1)-figSize(1)-xsep/2,ystart+axesSz(2)*2+ysep,figSize(1),0.5],...
                    'Orientation','horizontal','FontSize',fontLablSz);
                legend('boxoff');
                le2.ItemTokenSize(1) = 10;

                % Sliding Performance - Time
                ha3 = axes;
                set(ha3, 'units', 'centimeters', 'position', [xstart,ystart+(axesSz(2)+ysep).*2,axesSz],...
                    'nextplot', 'add', 'ylim', [0 100], 'xlim', tLim,'tickdir','out',...
                    'TickLength', [tickLen(1)/max(axesSz),tickLen(2)/max(axesSz)],'fontsize',fontAxesSz);
%                 xlabel('Time (min)','FontSize',fontLablSz);
                ylabel('Performance (%)','FontSize',fontLablSz);
                
                if ~isempty(idxW1)
                    fillCriterion(tbt(idxW1,:),[1.5,2],htLim,cCyan)
                end
                if ~isempty(idxW2)
                    fillCriterion(tbt(idxW2,:),[1.5,0.6],htLim,cCyan)
                end
                line([timeSep timeSep],[0 100],'color','k','linewidth',1,'linestyle','--');
                if ~isempty(expName)
                    line([switchTime switchTime],[0 100],'color',cRed,'linewidth',2,'linestyle','-');
                end
                for j=1:length(sessName)
                    idxSess = tbt.Date==sessName(j);
                    [xc,yc] = calMovAVG(tbt.TimeElapsedMerge(idxSess),tbt.Outcome(idxSess),...
                        'winSize',winSz,'stepSize',stepSz,'tarStr','Cor');
                    [xp,yp] = calMovAVG(tbt.TimeElapsedMerge(idxSess),tbt.Outcome(idxSess),...
                        'winSize',winSz,'stepSize',stepSz,'tarStr','Pre');
                    [xl,yl] = calMovAVG(tbt.TimeElapsedMerge(idxSess),tbt.Outcome(idxSess),...
                        'winSize',winSz,'stepSize',stepSz,'tarStr','Late');
                    l1 = plot(xc, yc, 'o', 'linestyle', '-', 'color', cCPL(1,:), ...
                        'markersize', 5, 'linewidth', 1.2, 'markerfacecolor', cCPL(1,:),...
                        'markeredgecolor', 'w');
                    l2 = plot(xp, yp, 'o', 'linestyle', '-', 'color', cCPL(2,:), ...
                        'markersize', 5, 'linewidth', 1.2, 'markerfacecolor', cCPL(2,:),...
                        'markeredgecolor', 'w');
                    l3 = plot(xl, yl, 'o', 'linestyle', '-', 'color', cCPL(3,:), ...
                        'markersize', 5, 'linewidth', 1.2, 'markerfacecolor', cCPL(3,:),...
                        'markeredgecolor', 'w');
                end
                le1 = legend([l1 l2 l3],{'Cor','Pre','Late'},'units','centimeters',...
                    'Position',[xstart+axesSz(1)-figSize(1)-xsep/2,ystart+axesSz(2)*3+ysep*2,figSize(1),0.5],...
                    'Orientation','horizontal','FontSize',fontLablSz);
                legend('boxoff');
                le1.ItemTokenSize(1) = 10;
                
                function fillCriterion(T,criterion,yLim,color)
                    % criterion = [1.5,2];
                    idxCri = abs((T.FP-criterion(1)))<1E-4 & abs((T.RW-criterion(2)))<1E-4;
                    diffCri = diff([0;idxCri;0]);
                    prdCri = [find(diffCri==1),find(diffCri==-1)-1];
                    for i=1:size(prdCri,1)
                        fill([repelem(T.TimeElapsedMerge(prdCri(i,1)),2),repelem(T.TimeElapsedMerge(prdCri(i,2)),2)],...
                            [yLim(1),yLim(2),yLim(2),yLim(1)],color,'EdgeColor','none','FaceAlpha',0.1);
                    end
                end
            end

            function h = compExpPlot(Obj)

                % PDF & CDF: use ExperimentByExperiment date, merge sessions
                ebe = Obj.EBE(Obj.EBE.Experiment ~= 'reject', :);
                idx1 = find(ebe.Experiment == expName{1});
                idx2 = find(ebe.Experiment == expName{2});
                fplist = [0.5 1.0 1.5];

                sbs = Obj.SBS(Obj.SBS.Experiment ~= 'reject', :);
                sbs_exp_idx = arrayfun(@(x) find(sbs.Experiment == x), expName, 'UniformOutput', false);
                sbs_exp{1} = sbs(sbs_exp_idx{1}, :);
                sbs_exp{2} = sbs(sbs_exp_idx{2}, :);
                tbt = Obj.TBT(Obj.TBT.Experiment ~= 'reject', :);

                figPos = [2 2 17 15];
                h = figure(2);clf(h);
                set(h, 'unit', 'centimeters', 'position', figPos,...
                    'paperpositionmode', 'auto', 'color', 'w');

                % HTpdf by FP
                a1 = axes;
                a1x = 1.5; a1y = 1.5;
                a1width = 4; a1h8 = 3;
                
                set(a1, 'units', 'centimeters', 'position', [a1x a1y a1width a1h8],...
                    'nextplot', 'add', 'ylim', [0 3.2], 'xlim', [0 2.5],'tickdir','out');
                xlabel('HoldTime (sec)', 'FontSize',fontLablSz);
                ylabel('PDF (1/s)', 'FontSize',fontLablSz);
                plot(0.025:0.05:2.475, ebe.HTpdf_FP1(idx1,:), 'Color', cExp(idx1,:), 'LineStyle', '-', 'LineWidth', 1.0);
                plot(0.025:0.05:2.475, ebe.HTpdf_FP1(idx2,:), 'Color', cExp(idx2,:), 'LineStyle', '-', 'LineWidth', 1.0);
                htpdf2_exp1 = plot(0.025:0.05:2.475, ebe.HTpdf_FP2(idx1,:), 'Color', cExp(idx1,:), 'LineStyle', '-', 'LineWidth', 1.8);
                htpdf2_exp2 = plot(0.025:0.05:2.475, ebe.HTpdf_FP2(idx2,:), 'Color', cExp(idx2,:), 'LineStyle', '-', 'LineWidth', 1.8);
                plot(0.025:0.05:2.475, ebe.HTpdf_FP3(idx1,:), 'Color', cExp(idx1,:), 'LineStyle', '-', 'LineWidth', 2.5);
                plot(0.025:0.05:2.475, ebe.HTpdf_FP3(idx2,:), 'Color', cExp(idx2,:), 'LineStyle', '-', 'LineWidth', 2.5);
                % legend([htpdf2_exp1 htpdf2_exp2], ebe.Experiment(1:2), 'Box', 'off', 'Location', 'northeast', 'FontSize', fontLablSz);

                % HTcdf by FP
                b1 = axes;
                b1x = a1x; b1y = a1y + a1h8 + 1.5;
                b1width = a1width; b1h8 = a1h8;
                set(b1, 'units', 'centimeters', 'position', [b1x b1y b1width b1h8],...
                    'nextplot', 'add', 'ylim', [0 1.1], 'xlim', [0 2.5], ...
                    'ytick', 0:0.5:1.0, 'yticklabels', {'0', '50', '100'}, 'tickdir','out');
                xlabel('HoldTime (sec)', 'FontSize', fontLablSz);
                ylabel('CDF (%)', 'FontSize', fontLablSz);
                plot(0.025:0.05:2.475, ebe.HTcdf_FP1(idx1,:), 'Color', cExp(idx1,:), 'LineStyle', '-', 'LineWidth', 1.0);
                plot(0.025:0.05:2.475, ebe.HTcdf_FP1(idx2,:), 'Color', cExp(idx2,:), 'LineStyle', '-', 'LineWidth', 1.0);
                htcdf2_exp1 = plot(0.025:0.05:2.475, ebe.HTcdf_FP2(idx1,:), 'Color', cExp(idx1,:), 'LineStyle', '-', 'LineWidth', 1.8);
                htcdf2_exp2 = plot(0.025:0.05:2.475, ebe.HTcdf_FP2(idx2,:), 'Color', cExp(idx2,:), 'LineStyle', '-', 'LineWidth', 1.8);
                plot(0.025:0.05:2.475, ebe.HTcdf_FP3(idx1,:), 'Color', cExp(idx1,:), 'LineStyle', '-', 'LineWidth', 2.5);
                plot(0.025:0.05:2.475, ebe.HTcdf_FP3(idx2,:), 'Color', cExp(idx2,:), 'LineStyle', '-', 'LineWidth', 2.5);
%                 legend(b1, [htcdf2_exp1 htcdf2_exp2], expName, 'Units', 'centimeters', ...
%                     'Box', 'off', 'Position', [b1x+b1width-1 b1y 1 1], 'FontSize', fontLablSz);
                
                % HT fwhm plot (by FP)
                a2 = axes;
                a2x = a1x + a1width + 1.5; a2y = a1y;
                a2width = 4; a2h8 = a1h8;
                set(a2, 'units', 'centimeters', 'position', [a2x a2y a2width a2h8], 'nextplot', 'add','tickDir', 'out',...
                    'xlim',[fplist(1)-0.25,fplist(end)+0.25],'xtick',fplist,'xticklabel',cellstr(string(fplist.*1000)),'fontsize',7, ...
                    'ylim',[0.2 0.7],'ytick',0.2:0.2:0.6,'yticklabels',{'200','400','600'},'ticklength', [0.02 0.025]);
                
                fwhmList(1,:) = [ebe.HTpdf_FP_GaussFWHM1(idx1,:) ebe.HTpdf_FP_GaussFWHM2(idx1,:) ebe.HTpdf_FP_GaussFWHM3(idx1,:)];
                fwhmList(2,:) = [ebe.HTpdf_FP_GaussFWHM1(idx2,:) ebe.HTpdf_FP_GaussFWHM2(idx2,:) ebe.HTpdf_FP_GaussFWHM3(idx2,:)];
                plot(fplist, fwhmList(1,:), 'o-', 'linewidth', 1, ...
                    'color', cExp(idx1,:), 'markerfacecolor', cExp(idx1,:), 'markeredgecolor','w', 'markersize', 5)
                plot(fplist, fwhmList(2,:), 'o-', 'linewidth', 1, ...
                    'color', cExp(idx2,:), 'markerfacecolor', cExp(idx2,:), 'markeredgecolor','w', 'markersize', 5)
                
                xlabel('Foreperiod (ms)','Fontsize',fontLablSz,'FontName','Arial')
                ylabel('FWHM of HTpdf (ms)','Fontsize',fontLablSz,'FontName','Arial')

                % RT mean-sem plot (by FP)
                b2 = axes;
                b2x = b1x + b1width + 1.5; b2y = b1y;
                b2width = a2width; b2h8 = b1h8;
                set(b2, 'units', 'centimeters', 'position', [b2x b2y b2width b2h8], 'nextplot', 'add','tickDir', 'out',...
                    'xlim',[fplist(1)-0.25,fplist(end)+0.25],'xtick',fplist,'xticklabel',cellstr(string(fplist.*1000)),'fontsize',7, ...
                    'ylim',[0.2 0.7],'ytick',0.2:0.2:0.6,'yticklabels',{'200','400','600'},'ticklength', [0.02 0.025]);
                
                plot(fplist, ebe.RelT_FP(idx1,:), 'o-', 'linewidth', 1, ...
                    'color', cExp(idx1,:), 'markerfacecolor', cExp(idx1,:), 'markeredgecolor','w', 'markersize', 5)
                plot(fplist, ebe.RelT_FP(idx2,:), 'o-', 'linewidth', 1, ...
                    'color', cExp(idx2,:), 'markerfacecolor', cExp(idx2,:), 'markeredgecolor','w', 'markersize', 5)
                
                xlabel('Foreperiod (ms)','Fontsize',fontLablSz,'FontName','Arial')
                ylabel('Reaction time (ms)','Fontsize',fontLablSz,'FontName','Arial')

                % Press duration: violin plot (FP*Experiment)
                a3 = axes;
                a3x = a2x + a2width + 1.5; a3y = a1y;
                a3width = 5; a3h8 = a1h8;
                set(a3, 'units', 'centimeters', 'position', [a3x a3y a3width a3h8], 'nextplot', 'add', ...
                    'xlim', [0.3 6.7], 'xtick', [1.5, 3.5, 5.5], ...
                    'xticklabels',{'500', '1000', '1500'},'fontsize',7, ...
                    'ylim',[0 2.5],'ytick',0:0.5:2.5, ...
                    'yticklabels',cellstr(string((0:0.5:2.5)*1000)), ...
                    'ticklength', [0.02 0.025], 'tickdir', 'out');
                xlabel('Foreperiod (ms)','Fontsize',fontLablSz,'FontName','Arial');
                ylabel('Press duration (ms)','Fontsize',fontLablSz,'FontName','Arial');

                v = violinplot(tbt.HT, tbt.FP+tbt.Experiment, 'ViolinColor', [cExp;cExp;cExp], ...
                    'GroupOrder', {'0.5DCZ25', '0.5Saline', '1DCZ25', '1Saline', '1.5DCZ25', '1.5Saline'}, ...
                    'ViolinAlpha', 0.3, 'MarkerSize', 6, ...
                    'ShowMedian', true, 'MedianColor', cRed, 'LineWidth', 3);
                
                % Error pattern scatter plot: use SessionBySession data, divided by exp.
                b3 = axes;
                b3x = b2x + b2width + 1.5; b3y = b2y;
                b3width = 3; b3h8 = 3;
                set(b3, 'units', 'centimeters', 'position', [b3x b3y b3width b3h8],...
                    'nextplot', 'add', 'ylim', [0 0.3], 'xlim', [0 0.3], ...
                    'tickdir', 'out', 'XTick', 0:0.1:0.3, 'YTick', 0:0.1:0.3, 'XTickLabel', 0:10:30, 'YTickLabel', 0:10:30);
                
                xlabel('Premature (%)', 'FontSize', fontLablSz);
                ylabel('Late (%)', 'FontSize', fontLablSz);
                sc1_error1 = scatter(sbs_exp{1}.Pre, sbs_exp{1}.Late, 'MarkerFaceColor', cExp(1, :), 'MarkerEdgeColor', 'none');
                errorbar(mean(sbs_exp{1}.Pre), mean(sbs_exp{1}.Late), ...
                    sem(sbs_exp{1}.Late), sem(sbs_exp{1}.Late), ...  % y neg, y pos
                    sem(sbs_exp{1}.Pre), sem(sbs_exp{1}.Pre), ...    % x neg, x pos
                    'o', 'MarkerFaceColor', cExp(1, :), 'MarkerEdgeColor', cRed, 'CapSize', 3, 'Color', cRed, 'LineWidth', 1.2);      
                sc1_error2 = scatter(sbs_exp{2}.Pre, sbs_exp{2}.Late, 'MarkerFaceColor', cExp(2, :), 'MarkerEdgeColor', 'none');
                errorbar(mean(sbs_exp{2}.Pre), mean(sbs_exp{2}.Late), ...
                    sem(sbs_exp{2}.Late), sem(sbs_exp{2}.Late), ...  % y neg, y pos
                    sem(sbs_exp{2}.Pre), sem(sbs_exp{2}.Pre), ...    % x neg, x pos
                    'o', 'MarkerFaceColor', cExp(2, :), 'MarkerEdgeColor', cRed, 'CapSize', 3, 'Color', cRed, 'LineWidth', 1.2);   
                line([0 100], [0 100], 'LineStyle', ':', 'Color', cGray, 'LineWidth', 1.5);
                legend(b3, [sc1_error1 sc1_error2], ebe.Experiment(1:2), 'Units', 'centimeters', ...
                    'Box', 'off', 'Position', [b3x+b3width+0.5 b3y+b3h8-2.5 1 1], 'FontSize', fontLablSz);

                xfinal = a3x + a3width + 1.5;
                yfinal = b2y + b2h8 + 1.2;
                set(h, 'position', [2 2 xfinal yfinal]);
                uicontrol(h, 'Style', 'text', 'units', 'centimeters',...
                    'position', [xfinal/2-4,yfinal-0.8, 8, 0.5],...
                    'string', append(Obj.Subject, ' / ', expName{1}, ' vs. ', expName{2}),...
                    'fontsize', fontTitlSz, 'fontweight', 'bold','backgroundcolor', [1 1 1]);

%                 function err = expErrorbar(data, field, color)
% 
%                     if nargin == 2
%                         color = 'k';
%                     end
%                     field = string(field);
% 
%                     tempdata = eval("normalize([data{1}."+field+"; data{2}."+field+"], 'range')");
%                     normdata{1} = tempdata(1:height(data{1}));
%                     normdata{2} = tempdata((height(data{1})+1):end);
% 
%                     mMethod = "mean"; eMethod = "sem";
% 
%                     xdata = eval(mMethod+"(normdata{1})");
%                     ydata = eval(mMethod+"(normdata{2})");
%                     xerr = eval(eMethod+"(normdata{1})");
%                     yerr = eval(eMethod+"(normdata{2})");
% 
%                     err = errorbar(xdata, ydata, yerr, yerr, xerr, xerr, ...
%                         'o', 'CapSize', 3, 'Color', color, 'LineWidth', 1.2); 
%                 end
            end

        end

    end
end

function stat = calIndivStat(data,multiSession,opts)
% calculate the STATs of one subject
% STATs of 1 session or across sessions (but in the same Experiment & Task)
    arguments
        data
        multiSession = false
        opts.fplist = []
        opts.ifDistr = false
        opts.edges_HT = 0:0.05:2.5 % Hold time (All trials)
        opts.bins_HT = 0.025:0.05:2.475
        opts.edges_RT = 0:0.025:0.6 % Reaction time (Cor)
        opts.edges_RelT = 0:0.05:1 % Release time (Cor+Late)
        opts.smoWin = 8 % smoothdata('gaussian')
        opts.GaussEqn = 'a1*exp(-((x-b1)/c1)^2)+a2*exp(-((x-b2)/c2)^2)';
        opts.StartPoints = [1 1 1 2 2 1];
        opts.LowerBound = [0 0 0 0 0 0];
        opts.UpperBound = [10 10 10 10 10 10];
    end
    if isempty(opts.fplist)
        fplist = unique(data.FP); % sorted from small to big
        if length(fplist) > 3 || length(fplist) == 1
        % adapt for wait(more than 3) and single FP protocols
            fplist = [0.5 1.0 1.5];
        end
    else
        fplist = opts.fplist;
    end
    
    stat = table;

    typename = unique(data.TrialType);
    for j=1:length(typename)
        t = struct;
        
        t.Subject = data.Subject(1);
        t.Group = data.Group(1);
        t.Experiment = data.Experiment(1);
        t.Task = data.Task(1);
        if ~multiSession
            t.Session = data.Session(1);
            t.Date = data.Date(1);
            t.DateTime = data.DateTime(1);
        else
            t.nSession = length(unique(data.Session));
        end
        
        t.TrialType = typename(j);
        tdata = data(data.TrialType==t.TrialType,:);
        
        if ~multiSession
            t.nBlock = length(unique(tdata.BlockNum));
        else
            nBlk = 0;
            uniSession = unique(tdata.Session);
            for iBlk=1:length(uniSession)
                nBlk = nBlk + length(unique(tdata(tdata.Session==uniSession(iBlk),:).BlockNum));
            end
        end
        
        t.nTrial = length(tdata.iTrial);
        t.Dark = sum(tdata.DarkTry);
        t.rTrial = t.nTrial./(t.Dark+t.nTrial);

        idxCor = contains(tdata.Outcome,'Cor');
        idxPre = contains(tdata.Outcome,'Pre');
        idxLate = contains(tdata.Outcome,'Late');
        t.Cor  = sum(idxCor)./t.nTrial;
        t.Pre  = sum(idxPre)./t.nTrial;
        t.Late = sum(idxLate)./t.nTrial;
        t.PreTendency = (t.Pre-t.Late)./(t.Pre+t.Late);

        if ~multiSession
            t.maxFP = max(tdata.FP);
            t.t2mFP = find(tdata.FP==t.maxFP,1,'first');
            t.minRW = min(tdata.RW);
            t.t2mRW = find(tdata.RW==t.minRW,1,'first');
            switch string(t.Task)
                case "Wait1"
                    t2c = find(abs(data.FP-1.5)<1e-4,1,'first');
                    if ~isempty(t2c)
                        t2cInv = 1./t2c;
                    else
                        t2c = NaN;
                        t2cInv = 0;
                    end
                case "Wait2"
                    t2c = find(abs(data.FP-1.5)<1e-4 & abs(data.RW-0.6)<1e-4,1,'first');
                    if ~isempty(t2c)
                        t2cInv = 1./t2c;
                    else
                        t2c = NaN;
                        t2cInv = 0;
                    end
                case "3FPs"
                    t2c = NaN;
                    t2cInv = NaN;
            end
            t.t2c = t2c;
            t.t2cInv = t2cInv;
        end
        
        t.HT = median(rmoutliers(tdata.HT,'quartiles'),'omitnan');
        rt = calRT(tdata.HT(idxCor), tdata.FP(idxCor),...
            'Remove100ms', 1, 'RemoveOutliers', 1, 'ToPlot', 0, 'Calse', 0);
        t.RT = rt.median;
        t.RT_IQR = diff(prctile(tdata.RT(idxCor), [25 75]));
        relt = calRT(tdata.HT(idxCor|idxLate), tdata.FP(idxCor|idxLate),...
            'Remove100ms', 1, 'RemoveOutliers', 1, 'ToPlot', 0, 'Calse', 0);
        t.RelT = relt.median;
        t.RelT_IQR = diff(prctile(tdata.HT(idxCor|idxLate)-tdata.FP(idxCor|idxLate), [25 75]));
        t.MT = median(rmoutliers(tdata.MT,'quartiles'),'omitnan');

        % Stat in each FP
        corFP = []; preFP = []; lateFP = []; htFP = []; htiqr_FP = [];
        rtFP = []; rt95ci_FP = []; rtiqr_FP = []; reltFP = []; relt95ci_FP = []; reltiqr_FP = []; mtFP = [];
        for iFP = 1:length(fplist)
            if iFP == 1
                idxThis = (tdata.FP>=0) & (tdata.FP<=fplist(iFP));
            else
                idxThis = (tdata.FP<=fplist(iFP)) & (tdata.FP>fplist(iFP-1));
            end
            if sum(idxThis) == 0
                corFP = [corFP, NaN];
                preFP = [preFP, NaN];
                lateFP = [lateFP, NaN];
                htFP = [htFP, NaN];
                htiqr_FP = [htiqr_FP, NaN];
                rtFP = [rtFP, NaN];
                rt95ci_FP = [rt95ci_FP, [NaN NaN]];
                rtiqr_FP = [rtiqr_FP, NaN];
                reltFP = [reltFP, NaN];
                relt95ci_FP = [relt95ci_FP, [NaN NaN]];
                reltiqr_FP = [reltiqr_FP, NaN];
                mtFP = [mtFP, NaN];
            else
                corFP = [corFP, sum(idxCor & idxThis)./sum(idxThis)];
                preFP = [preFP, sum(idxPre & idxThis)./sum(idxThis)];
                lateFP = [lateFP, sum(idxLate & idxThis)./sum(idxThis)];
                htFP = [htFP, median(rmoutliers(tdata.HT(idxThis),'quartiles'),'omitnan')];
                htiqr_FP = [htiqr_FP, iqr(tdata.HT(idxThis))];
                rtt = calRT_95CI(tdata.HT(idxCor & idxThis), tdata.FP(idxCor & idxThis),...
                'Remove100ms', 1, 'RemoveOutliers', 1, 'ToPlot', 0, 'Calse', 1);
                rtFP = [rtFP, rtt.median(1)];
                rt95ci_FP = [rt95ci_FP, rtt.median_95CI];
                rtiqr_FP = [rtiqr_FP, iqr(tdata.RT(idxCor & idxThis))];
                reltt = calRT_95CI(tdata.HT((idxCor|idxLate)&idxThis), tdata.FP((idxCor|idxLate)&idxThis),...
                'Remove100ms', 1, 'RemoveOutliers', 1, 'ToPlot', 0, 'Calse', 1);
                reltFP = [reltFP, reltt.median(1)];
                relt95ci_FP = [relt95ci_FP, reltt.median_95CI];
                reltiqr_FP = [reltiqr_FP, iqr(tdata.RelT((idxCor|idxLate) & idxThis))];
                mtFP = [mtFP, median(rmoutliers(tdata.MT(idxThis),'quartiles'),'omitnan')];
            end
        end
        t.Cor_FP = corFP;
        t.Pre_FP = preFP;
        t.Late_FP = lateFP;
        t.PreTendency_FP = (preFP-lateFP)./(preFP+lateFP);
        t.HT_FP = htFP;
        t.HT_IQR_FP = htiqr_FP;
        t.RT_FP = rtFP;
        t.RT_CI95_FP = rt95ci_FP;
        t.RT_IQR_FP = rtiqr_FP;
        t.RelT_FP = reltFP;
        t.RelT_CI95_FP = relt95ci_FP;
        t.RelT_IQR_FP = reltiqr_FP;
        t.MT_FP = mtFP;

        % calculate distribution
        if opts.ifDistr
            t.HTpdf = smoothdata(histcounts(tdata.HT,...
                opts.edges_HT,'Normalization','pdf'),2,'gaussian',opts.smoWin);
            t.RTpdf = smoothdata(histcounts(tdata.RT(idxCor),...
                opts.edges_RT,'Normalization','pdf'),2,'gaussian',opts.smoWin);
            t.RelTpdf = smoothdata(histcounts(tdata.HT(idxCor|idxLate)-tdata.FP(idxCor|idxLate),...
                opts.edges_RelT,'Normalization','pdf'),2,'gaussian',opts.smoWin);
            t.HTcdf = smoothdata(histcounts(tdata.HT,...
                opts.edges_HT,'Normalization','cdf'),2,'gaussian',opts.smoWin);
            t.RTcdf = smoothdata(histcounts(tdata.RT(idxCor),...
                opts.edges_RT,'Normalization','cdf'),2,'gaussian',opts.smoWin);
            t.RelTcdf = smoothdata(histcounts(tdata.HT(idxCor|idxLate)-tdata.FP(idxCor|idxLate),...
                opts.edges_RelT,'Normalization','cdf'),2,'gaussian',opts.smoWin);
            
            for iFP = 1:length(fplist)
                idxThis = tdata.FP==fplist(iFP);
                
                t.(['HTpdf_FP',num2str(iFP)]) = smoothdata(histcounts(tdata.HT(idxThis),...
                    opts.edges_HT,'Normalization','pdf'),2,'gaussian',opts.smoWin);
                t.(['RTpdf_FP',num2str(iFP)]) = smoothdata(histcounts(tdata.RT(idxCor&idxThis),...
                    opts.edges_RT,'Normalization','pdf'),2,'gaussian',opts.smoWin);
                t.(['RelTpdf_FP',num2str(iFP)]) = smoothdata(histcounts(tdata.HT((idxCor|idxLate)&idxThis)-...
                    tdata.FP((idxCor|idxLate)&idxThis),...
                    opts.edges_RelT,'Normalization','pdf'),2,'gaussian',opts.smoWin);
                t.(['HTcdf_FP',num2str(iFP)]) = smoothdata(histcounts(tdata.HT(idxThis),...
                    opts.edges_HT,'Normalization','cdf'),2,'gaussian',opts.smoWin);
                t.(['RTcdf_FP',num2str(iFP)]) = smoothdata(histcounts(tdata.RT(idxCor&idxThis),...
                    opts.edges_RT,'Normalization','cdf'),2,'gaussian',opts.smoWin);
                t.(['RelTcdf_FP',num2str(iFP)]) = smoothdata(histcounts(tdata.HT((idxCor|idxLate)&idxThis)-...
                    tdata.FP((idxCor|idxLate)&idxThis),...
                    opts.edges_RelT,'Normalization','cdf'),2,'gaussian',opts.smoWin);

                x = opts.bins_HT;
                y = t.(['HTpdf_FP', num2str(iFP)]);
                if ~any(isnan(y)) % the input of fit can't contain NaN
                    f = fit(x', y', opts.GaussEqn, ...
                        'Start', opts.StartPoints, 'Lower', opts.LowerBound, 'Upper',opts.UpperBound);
                    t.(['HTpdf_FP_GaussFWHM',num2str(iFP)]) = cmptFWHM(f, opts.edges_HT);
                else
                    t.(['HTpdf_FP_GaussFWHM',num2str(iFP)]) = NaN;
                end
            end

        end
        
        stat = [stat;struct2table(t)];
    end
end
