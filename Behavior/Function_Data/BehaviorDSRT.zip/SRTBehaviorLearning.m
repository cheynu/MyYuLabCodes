function BClassGroup = SRTBehaviorLearning(Meta)
% Jan 2023, Hanbo Wang & Yu Chen
% This script plots behavior data for SRT learning task
% Meta.
%   pathXls: the path containing the excel file which contains training info
%   pathAnm: the path, pathAnm\AnimalName\Protocol\DataFile.mat
%   pathArc: the path used to backup the extracted data and figures
%   plotDate: not used yet
%   YourName: not used yet
%   plotProg: if plot daily figures
%   plotIndiv: if plot individual figures
%   plotTypeIndiv: argument that decides the figure type
%   plotShadedExp: if the value of plotTypeIndiv is 'MixedFP', it decides what experiment is shaded
%   plotGroup: if plot group figures
%   reExtract: if reExtract info from raw data files. if not get info from extracted data
%   Subjects: extract the data of which it contains if it exists

% To run this script smoothly -->
% - Data should be organized as root/ANM/Stage/BpodRawData
% - Functions(packed in root/0_Function) used in this script:
%   @BehaviorDSRT
%   @BehaviorDSRT_Indiv
%   @BehaviorDSRT_Group
%   @calRT
%   @calMovAvg
%   @getSubContents
%   @appendSheets
% - Edit "Meta" in "Initiate" part:
%   Subjects and Group should be matched
%   TrialType: 'AutoShaping', 'LeverPress', 'LeverRelease', 'Wait', '3FPs'
%   Injection: if inject saline/DCZ in different sessions, add this field

% Extracted data will be stored as .mat file in root/ANM/Stage
% Figures will be stored in root/1_Archive/Stage/ANM

%% Initiate, check data structure and build paths
if ~isfield(Meta,'pathXls')
    rpath = pwd;
else
    rpath = Meta.pathXls;
end

if ~isfield(Meta,'pathAnm')
    if ~isfolder(fullfile(pwd, '2_ANMs'))
        error('ANMs folders not input and found');
    else
        pathAnm = fullfile(pwd, '2_ANMs');
    end
else
    pathAnm = Meta.pathAnm;
end

if ~isfield(Meta,'pathArc')
    if ~isfolder(fullfile(pwd, '1_Archive'))
        error('Archive folders not input and found');
    else
        pathArc = fullfile(pwd, '1_Archive');
    end
else
    pathArc = Meta.pathArc;
end

if ~isfield(Meta, 'Subjects')
    Meta.Subjects = arrayfun(@(x)x.name, getSubContents(pathAnm), 'UniformOutput', false);
end

if ~isfield(Meta, 'Protocol')
    error('Check field "Protocol" in Meta');
end

if ~isfield(Meta, 'reExtract')
    Meta.reExtract = true;
end

if ~isfield(Meta, 'plotProg')
    Meta.plotProg = true;
end

if ~isfield(Meta, 'plotIndiv')
    Meta.plotIndiv = true;
end

if ~isfield(Meta, 'plotTypeIndiv')
    Meta.plotTypeIndiv = 'Learning';
end

if ~isfield(Meta, 'plotShadedExp')
    Meta.plotShadedExp = 'DCZ';
end

if ~isfield(Meta, 'plotGroup')
    Meta.plotGroup = true;
end

TrainingLogXls = dir(fullfile(rpath,'TrainingLog*.xls'));
if isempty(TrainingLogXls)
    error('File "TrainingLog" not found');
elseif length(TrainingLogXls) > 1
    TrainingLog = appendSheets(uigetfile(fullfile(rpath,'TrainingLog*.xls')), Meta.Subjects);
else
    TrainingLog = appendSheets(TrainingLogXls(1).name, Meta.Subjects);
end

rxivPath = fullfile(pathArc, Meta.Protocol);
[~, ~] = mkdir(rxivPath);
groupArcPath = fullfile(rxivPath, 'GroupSummary');
[~, ~] = mkdir(groupArcPath);
progArcPath = fullfile(rxivPath, 'Progress');
[~,~] = mkdir(progArcPath);
indivArcPath = fullfile(rxivPath, 'Individual');
[~,~] = mkdir(indivArcPath);

ptclPath = cell(length(Meta.Subjects), 1);
for i = 1:length(Meta.Subjects)
    ptclPath{i} = fullfile(pathAnm, Meta.Subjects{i}, Meta.Protocol);
%     [~,~] = mkdir(fullfile(indivArcPath, Meta.Subjects{i}));
end

%% Extract Data as BClass & BClass_Indiv
ptclBClass = cell(length(Meta.Subjects), 1);  % rxiv cell for building BClass_Group
for i = 1:length(ptclPath)  % i = subject num

    if isfolder(ptclPath{i})

        cd(ptclPath{i});
        iLog = TrainingLog(ismember(TrainingLog.Subject,Meta.Subjects{i}), :);
    
        [~, ~] = mkdir('0_Summary');
        summaryPath = fullfile(ptclPath{i}, '0_Summary');
        dataPath = arrayfun(@(x)x.name, dir('20*'), 'UniformOutput', false);
    
        sbjBClass = cell(1, length(dataPath));  % rxiv cell for building BClass_Indiv
        % extract and processing
        for j = 1:length(dataPath)  % j = date num
    
            jPath = fullfile(ptclPath{i}, dataPath{j});
            cd(jPath);
            jLog = iLog(iLog.Date == str2double(dataPath{j}), :);
    
            % Re-generate BClass when: Meta.reExtract is true || no/multiple such file
            if Meta.reExtract || length(dir('BClass*.mat')) ~= 1
                delete('BClass*');  % delete old BClass* files
                FileNames = arrayfun(@(x)x.name, dir('*DSRT*.mat'), 'UniformOutput', false);
                for k = 1:length(FileNames)  % k = session num
                    if k == 1
                        BClass = BehaviorDSRT(FileNames{k});
                    else
                        kBClass = BehaviorDSRT(FileNames{k});
                        BClass = BClass.merge(kBClass);  % Merge files of one day
                    end
    
                    jGroup = jLog.Group;
                    if iscell(jGroup)
                        BClass.Group = jLog.Group{:};
                    elseif isnan(jGroup)
                        BClass.Group = '';
                    else
                        error('Check "Group" in Trianinglog.xls');
                    end
    
                    jExp = jLog.Experiment;
                    if iscell(jExp)
                        BClass.Experiment = jLog.Experiment{:};
                    elseif isnan(jExp)
                        BClass.Experiment = '';
                    else
                        error('Check "Experiment" in Trianinglog.xls');
                    end
                    BClass.save();
                    BClass.save(fullfile(progArcPath, Meta.Subjects{i})); % archive
                end
            else
                BClassName = arrayfun(@(x)x.name, dir('BClass*.mat'), 'UniformOutput', false);
                BClass = load(BClassName{:});
                BClass = BClass.obj;  % BClass*.mat is saved as BClass.obj (struct)
            end
    
            if Meta.plotProg
                BClass.print('Fig');
                BClass.print(fullfile(progArcPath, Meta.Subjects{i}, 'Fig')); % archive
            end
            sbjBClass{j} = BClass;
        end
    
        cd(summaryPath);
        if Meta.reExtract || length(dir('BClassIndiv*.mat')) ~= 1
            delete('BClassIndiv*');  % delete old BClass* files
            BClassIndiv = BehaviorDSRT_Indiv(sbjBClass);
            BClassIndiv.save();
            BClassIndiv.save(fullfile(indivArcPath,Meta.Subjects{i})); % archive
        else
            BClassIndivName = arrayfun(@(x)x.name, dir('BClassIndiv*.mat'), 'UniformOutput', false);
            BClassIndiv = load(BClassIndivName{:});
            BClassIndiv = BClassIndiv.obj;
        end
    
        if Meta.plotIndiv
            indivFig = BClassIndiv.plot('plotType',Meta.plotTypeIndiv,'shadedExp',Meta.plotShadedExp);
            BClassIndiv.print('tarFig', indivFig, 'tarDir', fullfile(summaryPath, 'Fig'));
            BClassIndiv.print('tarFig', indivFig, 'tarDir', fullfile(indivArcPath, '0_Fig'));
%             BClassIndiv.print('tarFig', indivFig, 'tarDir', fullfile(indivArcPath,Meta.Sujects{i}, '0_Fig'));
        end
        ptclBClass{i} = BClassIndiv;
    else
        ptclBClass{i} = {};
    end
    

end

% BClass_Group
cd(groupArcPath);
if Meta.reExtract || length(dir('BClassGroup*.mat')) ~= 1
    delete('BClassGroup*');  % delete old BClass* files
    BClassGroup = BehaviorDSRT_Group(ptclBClass);
    BClassGroup.save();
else
    BClassGroupName = arrayfun(@(x)x.name, dir('BClassGroup*.mat'), 'UniformOutput', false);
    BClassGroup = load(BClassGroupName{:});
    BClassGroup = BClassGroup.obj;
end

if Meta.plotGroup
    groupFig = BClassGroup.plot('plotType', 'Learning');
    BClassIndiv.print('tarFig', groupFig, 'tarDir', fullfile(groupArcPath, 'Fig'));
end

end