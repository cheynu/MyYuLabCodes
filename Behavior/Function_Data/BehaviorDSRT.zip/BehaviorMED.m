classdef BehaviorMED < BehaviorDSRT
    %BEHAVIORMED 此处显示有关此类的摘要
    %   此处显示详细说明
    
    properties
        RawData
    end
    
    methods
        function obj = BehaviorMED(medfile,bpodfile)
            %BEHAVIORMED 构造此类的实例
            arguments
                medfile char {mustBeFile}
                bpodfile = [] % filename or SessionData struct
            end

            % pre-process by BehaviorClass of JianingYu
            [b,bc] = Behavior.MED.track_training(medfile);

            % Assignment
            % basic information
            data = struct;
            data.Subject = bc.Subject;
            data.Experiment = b.Metadata.Experiment;
            data.Date = str2double(bc.Date);
            data.DateTime = datetime([b.Metadata.Date 'T' b.Metadata.StartTime],'InputFormat','yyyyMMdd''T''HH:mm:ss');
            data.Task = bc.Protocol;
            data.MixedFP = round(bc.MixedFP./1000,2);

            idxDark = find(ismember(bc.Outcome,{'Dark'}));
            idxTrial = find(ismember(bc.Outcome,bc.PerformanceType));

            data.nTrial = length(idxTrial);
            data.iTrial = (1:data.nTrial)';
            data.BlockNum = ones(data.nTrial,1);
            data.TrialNum = data.iTrial;
            data.TrialType = repelem("Lever",data.nTrial)';
            data.ConfuseNum = zeros(data.nTrial,1);
            data.TimeElapsed = bc.PressTime(idxTrial)';
            % FP & RW
            if isempty(bc.FP) % Wait Period
                b = UpdateWaitB(b);
                bc.FP = b.FPs;
            end
            data.FP = bc.FP(idxTrial)'./1000;
            data.RW = nan(data.nTrial,1);
            % Outcome
            outcome = string(bc.Outcome(idxTrial));
            outcome = replace(outcome,{'Correct','Premature'},{'Cor','Pre'});
            data.Outcome = outcome';
            % Reaction time & Hold time
            rt = bc.ReactionTime(idxTrial);
            rt(outcome=="Pre" | outcome=="Late") = NaN;
            data.RT = rt';
            
            data.HT = (bc.ReleaseTime(idxTrial) - bc.PressTime(idxTrial))';
            %darktry
            idxDarkIni = [1 find(diff(idxDark)>1)+1];
            darkNum = [diff(idxDarkIni) length(idxDarkIni(end):length(idxDark))];
            idxDarkTrial = idxDark(idxDarkIni)-1;
            darktry = zeros(data.nTrial,1);
            darktry(ismember(idxTrial,idxDarkTrial)) = darkNum;
            data.DarkTry = darktry;
            
            % add Movement time
            if ~isempty(bpodfile)
                switch class(bpodfile)
                    case 'struct'
                        sd = bpodfile;
                    otherwise
                        mustBeFile(bpodfile);
                        load(bpodfile,'SessionData');
                        sd = SessionData;
                end
                % Extract BPOD data
                trialStart = nan(1,sd.nTrials);
                medTTL = nan(1,sd.nTrials);
                mt = nan(1,sd.nTrials);
                for i=1:sd.nTrials
                    trialStart(i) = sd.TrialStartTimestamp(i);
                    medTTL(i) = sd.RawEvents.Trial{i}.States.BriefReward(1); % if ~isnan, then mt ~isnan
                    mt(i) = diff(sd.RawEvents.Trial{i}.States.WaitForRewardEntry);
                end
                % Align BPOD to MED
                t_BPOD = trialStart + medTTL;
                idxTTL = ~isnan(t_BPOD);
                t_BPOD = t_BPOD(idxTTL);
                mt = mt(idxTTL);
                idxCL = data.Outcome=="Cor" | data.Outcome=="Late";
                t_MED = data.TimeElapsed(idxCL) + data.FP(idxCL); % Tone
                
                tTTLIndexBpod2MED = findseqmatchrev(t_MED, t_BPOD, 0, 0); % each TTL(bpod) in MED timestamp
                MT_medAll = nan(data.nTrial,1);
                MT_medCL = nan(sum(idxCL),1);
                MT_medCL(tTTLIndexBpod2MED) = mt;
                MT_medAll(idxCL) = MT_medCL;
                data.MT = MT_medAll;
            else
                data.MT = nan(data.nTrial,1);
            end

            % Inherit
            obj@BehaviorDSRT(data);

            % New properties
            obj.RawData = bc;
        end
    end
end

