% _________________________________________________________________________
% File:               Main_Wait_3FPs.m
% Created on:         Oct 6, 2021
% Created by:         Yu Chen
% Last revised on:    Oct 6, 2021
% Last revised by:    Yu Chen
% _________________________________________________________________________
% Required Functions:
%   med_to_tec_new
%   med_to_protocol
%   med_to_tec_fp
%   med_DataExtract
%   med_LearningPlot_Individual
%   med_3FPsPlot_Individual
% _________________________________________________________________________
% Required Packages:
% 'gramm' by Pierre Morel
% _________________________________________________________________________
% Protocol:
% 1. Add the folder path of this program to MATLAB's search path
% 2. Put all MED files to be analyzed in a specific folder
% 3. Run this code (Main_Wait_3FPs.m)
% 4. Select the folder containing MED files in dialog box
% 5. Extracted data are saved in selected folder as .mat file, and backup 
%   codes & result figures are saved in corresponding subfolders
% _________________________________________________________________________
% Caution:
% 1. Suggest put these codes into a specific folder and don't mixed with
%   data files.
% 2. There are probably some outputs in terminal.
%   - Orphan Press: The presses couldn't be classified into
%       correct/premature/late/inter-trial(dark), and they are finally
%       incorporated into inter-trial type. The index is for all presses.
%   - Mismatch FP or RW: The FP & RW data in Wait 1&2 are inferred by
%       specific rule. If the inferred values are not the same as the
%       recorded values that are calculated by events, the terminal would 
%       show the index of the mismatch value (index of all presses).
%% Initiate
clear;clc;
rng('default'); % Set the random seed for reproducibility of the results
%% Select The Path Containing Data
dataPath = uigetdir(path,'Select the directory containing data file'); %选择工作目录
cd(dataPath);
%% Extract & Save Data
FileNames = arrayfun(@(x)x.name, dir('*.txt'), 'UniformOutput', false);

btAll = cell(1,length(FileNames));

for i=1:length(FileNames)
%     bAll(i)=track_training_progress_advanced(FileNames{i}); % classic method
%     [bAll(i),btAll{i}] = med_DataExtract(FileNames{i},[1,0]); %plot
    [bAll(i),btAll{i}] = med_DataExtract(FileNames{i},[0,0]); %don't plot
    
end

savename = ['bmixedAll_' upper(bAll(i).Metadata.SubjectName)];
save(savename, 'bAll','btAll')
close all;
%% Analysis & Plot
% plotbAll(bAll)
med_LearningPlot_Individual(bAll,btAll);
% med_3FPsPlot_Individual(btAll);
%% Code Backup
codeSavePath = fullfile(dataPath,'CodeBackup');
if ~exist(codeSavePath,'dir')
    mkdir(codeSavePath);
end

curCodePath = mfilename('fullpath');
[codeFolder,~] = fileparts(curCodePath);

cd(codeFolder);
exeCodes = dir('*.m');
for i=1:size(exeCodes,1)
    copyfile(exeCodes(i).name,codeSavePath)
end
cd(dataPath);