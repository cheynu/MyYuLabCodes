These codes serve for processing the data from MED-Bpod behavior training system in Jianing Yu lab at Peking University.

!!!Please Add This Folder Path to MATLAB's Search Path!!!

Main Program:
  - Main_MT
  - Main_Wait_3FPs
  - Main_Wait_3FPs_Grouping

Function

  Basic
  - med_to_tec_new
  - med_to_protocol
  - med_to_tec_fp

  Data packaging
  - track_training_progress_advanced
  - med_DataExtract

  Plot
  - plotbAll
  - med_LearningPlot_Individual
  - med_LearningPlot_PairComp
  - med_3FPsPlot_Individual
  - med_3FPsPlot_PairComp
  - med_3FPsPlot_CrossComp

  STAT
  - compute_stat_summary