% _________________________________________________________________________
% File:               Main_Wait3FPs_Grouping.m
% Created on:         Jan 8, 2022
% Created by:         Yu Chen
% Last revised on:    Mar 14, 2022
% Last revised by:    Yu Chen
% _________________________________________________________________________
% Required Functions:
%   med_to_tec_new
%   med_to_protocol
%   med_to_tec_fp
%   med_DataExtract
%   med_LearningPlot_Individual
%   med_3FPsPlot_Individual
% _________________________________________________________________________
% Required Packages:
% 'gramm' by Pierre Morel
% _________________________________________________________________________
% Protocol:
% 1. Add the folder path of this program to MATLAB's search path
% 2. Put all MED files to be analyzed in a specific folder
% 3. Run this script
% 4. Select the folder containing MED files in dialog box % not updated
% 5. Extracted data are saved in selected folder as .mat file, and backup 
%   codes & result figures are saved in corresponding subfolders
% _________________________________________________________________________
% Caution:
% 1. Suggest put these codes into a specific folder and don't mixed with
%   data files.
% 2. There are probably some outputs in terminal.
%   - Orphan Press: The presses couldn't be classified into
%       correct/premature/late/inter-trial(dark), and they are finally
%       incorporated into inter-trial type. The index is for all presses.
%   - Mismatch FP or RW: The FP & RW data in Wait 1&2 are inferred by
%       specific rule. If the inferred values are not the same as the
%       recorded values that are calculated by events, the terminal would 
%       show the index of the mismatch value (index of all presses).
%% Initiate
clear;clc;
rng('default'); % Set the random seed for reproducibility of the results
ans_multi = questdlg('Do you want to process the data of multiple subjects?',...
    'Multiple Subject Mode','Multiple','Single','Single');
ans_plot = questdlg('Do you want to plot progress figures for each session?',...
    'Progress Plot','Plot','No Plot','Plot');
allProcess = string(ans_multi) == "Multiple";
plotmark = string(ans_plot) == "Plot"; % plot for each day's data or not
if allProcess==1
    ans_comp = questdlg('Do you want to compare the performances of two groups?',...
    'Grouping Plot','Grouping','No grouping','No grouping');
    compmark = string(ans_comp) == "Grouping";
else
    compmark = 0;
end
arcFolderName = '1_FigArchive';
% taskName = '3FPs';%% Select The Path Containing Data
%% Select The Path Containing Data
if allProcess
    sbjPath = uigetdir(path,'Select the directory containing the data of different subjects'); % 选择被试根目录
    examplePath = uigetdir(path,'Select the directory containing data file'); %选择某个data目录
    sbj_suffix = erase(examplePath,sbjPath);
    ind_sep = find(sbj_suffix==filesep);
    if length(ind_sep)>1
        task_suffix = sbj_suffix(ind_sep(2):end); % erase subject name
    else
        task_suffix = '';
    end
    
    sbjDir = dir(sbjPath);
    tarPath = {};
    addd = 1;
    orderName = {};
    for i=1:length(sbjDir)
        if isequal(sbjDir(i).name,'.') || isequal(sbjDir(i).name, '..') || ~sbjDir(i).isdir
            continue;
        end
        tmp_folder = [sbjPath, filesep, sbjDir(i).name, task_suffix];
        if isfolder(tmp_folder) && ~strcmp(tmp_folder,fullfile(sbjPath,arcFolderName))
            tmpPath{addd} = tmp_folder;
            orderName{addd} = sbjDir(i).name;
            addd = addd + 1;
        end
    end
    [idx1,tf1] = listdlg('PromptString','Select the subjects to be analyzed',...
        'ListString',orderName);
    if tf1
        tarPath = tmpPath(idx1);
        orderName = orderName(idx1);
    end
else
    examplePath = uigetdir(path,'Select the directory containing data file'); %选择某个data目录
    tarPath = {examplePath};
end

if compmark
    grpName = inputdlg({'Group 1 name','Group 2 name'},'Group names',[1 50],...
        {'Lesion','Sham'});
    [idx,tf] = listdlg('PromptString',{'Select subjects:',grpName{1}},...
        'ListString',orderName);
    if tf
        grpVar = string(zeros(length(orderName),1));
        grpVar(:) = "";
        grpVar(idx) = grpName{1};
        grpVar(grpVar=="") = grpName{2};
        btAll2d = {};
    else
        compmark = 0;
    end
end

for i=1:length(tarPath)

dataPath = tarPath{i};
cd(dataPath);
%% Extract & Save Data % Merge (if needed)
FileNames = arrayfun(@(x)x.name, dir('*.txt'), 'UniformOutput', false);

clear bAll;
btAll = cell(1,length(FileNames));

for i=1:length(FileNames)
%     bAll(i)=track_training_progress_advanced(FileNames{i}); % classic method
    [bAll(i),btAll{i}] = med_DataExtract(FileNames{i},[plotmark,0]);
end

savename = ['bmixedAll_' upper(bAll(i).Metadata.SubjectName)];
save(savename, 'bAll','btAll');

if compmark
    curCol = size(btAll,2);
    btAll2d(end+1,1:curCol) = btAll;
end
%% Analysis % Plot
% plotbAll(bAll)
h_learning = med_LearningPlot_Individual(bAll,btAll);
h_3FPs =  med_3FPsPlot_Individual(btAll);

if allProcess
    ArcFigPath = fullfile(sbjPath,arcFolderName);
    if ~exist(ArcFigPath,'dir')
        mkdir(ArcFigPath);
    end
    ArcFigName = btAll{1}.Subject(1) + "_" + btAll{1}.Date(1) + "-" + btAll{end}.Date(1);
    saveas(h_learning, fullfile(ArcFigPath,ArcFigName+"_LearningCurve"), 'png');
%     saveas(h_3FPs, fullfile(ArcFigPath,ArcFigName+"_3FPs"), 'png');
end
%% Code Backup
codeSavePath = fullfile(dataPath,'CodeBackup');
if ~exist(codeSavePath,'dir')
    mkdir(codeSavePath);
end

curCodePath = mfilename('fullpath');
[codeFolder,~] = fileparts(curCodePath);

cd(codeFolder);
exeCodes = dir('*.m');
for i=1:size(exeCodes,1)
    copyfile(exeCodes(i).name,codeSavePath);
end
cd(dataPath);

end
%% Grouping plot
if compmark
    cd(ArcFigPath);
    save('bmixedAllsbj', 'btAll2d', 'grpVar');
    med_LearningPlot_PairComp(btAll2d,grpVar);
    days = size(btAll2d,2);
    crossFilter = {};
    while 1
        [idx2,tf2] = listdlg('PromptString','Select the sessions# to be analyzed further',...
            'ListString',string(1:days));
        if tf2
            med_3FPsPlot_PairComp(btAll2d,grpVar,idx2);
            crossFilter{end+1} = idx2;
        else
            break;
        end
    end
    if length(crossFilter)==2
        med_3FPsPlot_CrossComp(btAll2d,grpVar,crossFilter);
    end
    cd(dataPath);
end