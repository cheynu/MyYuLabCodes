%% Initiate
clear;clc;
rng('default'); % Set the random seed for reproducibility of the results
plotmark = true; % plot for each day's data or not
%% Select The Path Containing Data
sbjPath = uigetdir(path,'Select the directory containing the data of different subjects'); % 选择被试根目录
examplePath = uigetdir(path,'Select the directory containing data file'); %选择某个data目录
sbj_suffix = erase(examplePath,sbjPath);
ind_sep = find(sbj_suffix==filesep);
task_suffix = sbj_suffix(ind_sep(2):end); % erase subject name

sbjDir = dir(sbjPath);
tarPath = {};
addd = 1;
for i=1:length(sbjDir)
    if isequal(sbjDir(i).name,'.') || isequal(sbjDir(i).name, '..') || ~sbjDir(i).isdir
        continue;
    end
    tmp_folder = [sbjPath, filesep, sbjDir(i).name, task_suffix];
    if isfolder(tmp_folder)
        tarPath{addd} = tmp_folder;
        addd = addd + 1;
    end
end

for i=1:length(tarPath)

dataPath = tarPath{i};
cd(dataPath);
%% Extract & Save Data
FileNames_all = arrayfun(@(x)x.name, dir('*.mat'), 'UniformOutput', false);
FileNames = {};
for i=1:length(FileNames_all)
    if ~strcmp(FileNames_all{i}(1:2),'B_') && ~strcmp(FileNames_all{i}(1:10),'bmixedAll_')
        FileNames = [FileNames;FileNames_all{i}];
    end
end

btAll = cell(1,length(FileNames)); % 'b'pod 't'able

for i=1:length(FileNames)
    btAll{i} = DSRT_DataExtract_Block(FileNames{i},plotmark);
end

savename = 'bmixedAll_' + upper(btAll{i}.Subject(1));
save(savename, 'btAll')

%% Analysis % Plot
DSRT_BlockPlot_Individual(btAll);

%% Code Backup
codeSavePath = fullfile(dataPath,'CodeBackup');
if ~exist(codeSavePath,'dir')
    mkdir(codeSavePath);
end

curCodePath = mfilename('fullpath');
[codeFolder,~] = fileparts(curCodePath);

cd(codeFolder);
exeCodes = dir('*.m');
for i=1:size(exeCodes,1)
    copyfile(exeCodes(i).name,codeSavePath)
end
cd(dataPath);

end