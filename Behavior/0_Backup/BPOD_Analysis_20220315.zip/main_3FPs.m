%% Initiate
clear;clc;
rng('default'); % Set the random seed for reproducibility of the results
ans_multi = questdlg('Do you want to process the data of multiple subjects?',...
    'Multiple Subject Mode','Multiple','Single','Single');
ans_plot = questdlg('Do you want to plot progress figures for each session?',...
    'Progress Plot','Plot','No Plot','Plot');
allProcess = string(ans_multi) == "Multiple";
plotmark = string(ans_plot) == "Plot"; % plot for each day's data or not
if allProcess==1
    ans_comp = questdlg('Do you want to compare the performances of two groups?',...
    'Grouping Plot','Grouping','No grouping','No grouping');
    compmark = string(ans_comp) == "Grouping";
else
    compmark = 0;
end
arcFolderName = '1_FigArchive';
taskName = '3FPs';
%% Select The Path Containing Data
if allProcess
    sbjPath = uigetdir(path,'Select the directory containing the data of different subjects'); % 选择被试根目录
    examplePath = uigetdir(path,'Select the directory containing data file'); %选择某个data目录
    sbj_suffix = erase(examplePath,sbjPath);
    ind_sep = find(sbj_suffix==filesep);
    if length(ind_sep)>1
        task_suffix = sbj_suffix(ind_sep(2):end); % erase subject name
    else
        task_suffix = '';
    end
    
    sbjDir = dir(sbjPath);
    tarPath = {};
    addd = 1;
    orderName = {};
    for i=1:length(sbjDir)
        if isequal(sbjDir(i).name,'.') || isequal(sbjDir(i).name, '..') || ~sbjDir(i).isdir
            continue;
        end
        tmp_folder = [sbjPath, filesep, sbjDir(i).name, task_suffix];
        if isfolder(tmp_folder) && ~strcmp(tmp_folder,fullfile(sbjPath,arcFolderName))
            tmpPath{addd} = tmp_folder;
            orderName{addd} = sbjDir(i).name;
            addd = addd + 1;
        end
    end
    [idx1,tf1] = listdlg('PromptString','Select the subjects to be analyzed',...
        'ListString',orderName);
    if tf1
        tarPath = tmpPath(idx1);
        orderName = orderName(idx1);
    end
else
    examplePath = uigetdir(path,'Select the directory containing data file'); %选择某个data目录
    tarPath = {examplePath};
end

if compmark
    grpName = inputdlg({'Group 1 name','Group 2 name'},'Group names',[1 50],...
        {'hM4D','GFP'});
    [idx,tf] = listdlg('PromptString',{'Select subjects:',grpName{1}},...
        'ListString',orderName);
    if tf
        grpVar = string(zeros(length(orderName),1));
        grpVar(:) = "";
        grpVar(idx) = grpName{1};
        grpVar(grpVar=="") = grpName{2};
        btAll2d = {};
    else
        compmark = 0;
    end
end

for i=1:length(tarPath)

dataPath = tarPath{i};
cd(dataPath);
%% Extract & Save Data % Merge (if needed)
FileNames_all = arrayfun(@(x)x.name, dir('*.mat'), 'UniformOutput', false);
FileNames = {};
for i=1:length(FileNames_all)
    if ~strcmp(FileNames_all{i}(1:2),'B_') && ~strcmp(FileNames_all{i}(1:10),'bmixedAll_')
        FileNames = [FileNames;FileNames_all{i}];
    end
end

btAll = cell(1,length(FileNames)); % 'b'pod 't'able

for i=1:length(FileNames)
    btAll{i} = DSRT_DataExtract_Block(FileNames{i},plotmark);
end
method = {'raw','merge','select'};
btAll = DSRT_DataMerge(btAll,method{2});

savename = 'bmixedAll_' + upper(btAll{end}.Subject(1));
save(savename, 'btAll')

if compmark
    curCol = size(btAll,2);
    btAll2d(end+1,1:curCol) = btAll;
end
%% Analysis % Plot
h_prog = DSRT_ProgSum_Individual(btAll,taskName);
h_wait = DSRT_WaitPlot_Individual(btAll,taskName);

if allProcess
    ArcFigPath = fullfile(sbjPath,arcFolderName);
    if ~exist(ArcFigPath,'dir')
        mkdir(ArcFigPath);
    end
    ArcFigName = btAll{1}.Subject(1) + "_" + btAll{1}.Date(1) + "-" + btAll{end}.Date(1);
    saveas(h_prog, fullfile(ArcFigPath,ArcFigName+"_prog"), 'png');
    saveas(h_wait, fullfile(ArcFigPath,ArcFigName+"_"+lower(taskName)), 'png');
end
%% Code Backup
codeSavePath = fullfile(dataPath,'CodeBackup');
if ~exist(codeSavePath,'dir')
    mkdir(codeSavePath);
end

curCodePath = mfilename('fullpath');
[codeFolder,~] = fileparts(curCodePath);

cd(codeFolder);
exeCodes = dir('*.m');
for i=1:size(exeCodes,1)
    copyfile(exeCodes(i).name,codeSavePath)
end
cd(dataPath);

end
%% Grouping plot
if compmark
    cd(ArcFigPath);
    save('bmixedAllsbj', 'btAll2d');
    DSRT_WaitPlot_PairComp(btAll2d,grpVar,taskName);
    cd(dataPath);
end

%% Function
function out = DSRT_DataMerge(btAll,method)

switch nargin
    case 1
        method = 'select';
    otherwise
        %pass;
end

date = [];
for i=1:length(btAll)
    date(i) = btAll{i}.Date(1);
end
if length(unique(date))==length(btAll)
    out = btAll;
    return;
end
pAll = {};p = 1;
out = {};o = 1;
rec = [];
for i=1:length(date)
    tdate = date;
    tdate(i) = [];
    if ismember(date(i),tdate)
        pending = find(date==date(i));
        date(pending) = NaN;
        pAll{p} = pending;
        p = p + 1;
        out{o} = {};
        rec = [rec,o];
        o = o + 1;
    else
        if ~isnan(date(i))
            out{o} = btAll{i};
            o = o + 1;
        end
    end
end
irec = 1;
switch lower(method)
    case 'raw'
        % pass
    case 'merge'
        for i=1:length(pAll)
            mday = table;
            end_trial = 0;
            end_block = 0;
            end_time = 0;
            for j=1:length(pAll{i})
                tday = btAll{pAll{i}(j)};
                tday.iTrial = tday.iTrial + end_trial;
                end_trial = tday.iTrial(end);
                tday.BlockNum = tday.BlockNum + end_block;
                end_block = tday.BlockNum(end);
                tday.TimeElapsed = tday.TimeElapsed + end_time + 60; %60s delay
                end_time = tday.TimeElapsed(end);
                mday = [mday;tday];
            end
            out{rec(irec)} = mday;
            irec = irec + 1;
        end
    case 'select'
        for i=1:length(pAll)
            maxrow = 0;
            for j=1:length(pAll{i})
                tmprow = size(btAll{pAll{i}(j)},1);
                if tmprow>maxrow
                    maxrow = tmprow;
                    mday = btAll{pAll{i}(j)};
                end
            end
            out{rec(irec)} = mday;
            irec = irec + 1;
        end
end

end